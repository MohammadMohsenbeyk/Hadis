package ir.wexipe.ayahwidget.data

import ir.wexipe.ayahwidget.widget.AppFont

enum class HAlign { LEFT, CENTER, RIGHT }
enum class VAlign { TOP, CENTER, BOTTOM }

/** Which physical side of the text the counter button sits on. */
enum class CounterSide { LEFT, RIGHT }

/** Allowed ranges for every numeric setting (used by the UI sliders and by the codec). */
object Limits {
    val fontSize = 12f..40f          // preferred (maximum) text size, sp
    val minFontSize = 8f..20f        // readability floor of the smart fit, sp
    val textScaleX = 0.85f..1.15f    // horizontal glyph scale chosen by the user
    val minTextScaleX = 0.80f..1.0f  // lowest scale the smart fit may compress to
    val lineSpacing = 1.1f..2.2f     // line pitch as a multiple of the font size
    val letterSpacing = 0f..0.2f     // em
    val preferredLines = 1..4
    val opacity = 0..100
    val cornerRadius = 0..48
    val sizePercent = 30..100
    val margin = 0..32
    val padding = 0..40
    val counterGap = 0..32           // dp, button block to text
    val buttonScale = 0.7f..1.4f     // multiplier on the automatic button size
    val buttonRadius = 0..36         // dp
    val numberScale = 0.5f..1.2f     // multiplier on the text size
    val numberGap = 0..12            // dp, number to button
}

/**
 * Everything that describes how the widget LOOKS. It does not contain the text or the counters
 * (those belong to a TextItem), so a style can be saved as a preset and applied to any text.
 *
 * The defaults are a designed preset, not arbitrary numbers:
 *  - the button is sized from the real height of the text block (see CardPlanner), so there is no
 *    absolute button size here, only a multiplier;
 *  - the button radius follows the card radius (Same as widget);
 *  - the card is a very light sky blue at low opacity, the button a soft navy at lower opacity;
 *  - the heaviest weight (Bold) is the default font.
 */
data class WidgetStyle(
    // Text
    val font: AppFont = AppFont.BOLD,
    val fontSizeSp: Float = 22f,
    val minFontSizeSp: Float = 12f,
    val textScaleX: Float = 1.0f,
    val minTextScaleX: Float = 0.92f,
    val lineSpacing: Float = 1.40f,
    val letterSpacingEm: Float = 0f,
    val preferredLines: Int = 2,
    val equalLines: Boolean = true,
    val textColor: Int = 0xFF0E1E3C.toInt(),
    // Widget card
    val bgColor: Int = 0xFFE3F1FF.toInt(),
    val bgOpacityPercent: Int = 60,
    val cornerRadiusDp: Int = 14,
    val widthPercent: Int = 100,
    val heightPercent: Int = 100,
    val autoHeight: Boolean = true,
    val marginDp: Int = 4,
    val paddingTopDp: Int = 8,
    val paddingBottomDp: Int = 8,
    val paddingStartDp: Int = 12,
    val paddingEndDp: Int = 12,
    val hAlign: HAlign = HAlign.CENTER,
    val vAlign: VAlign = VAlign.CENTER,
    // Counter button
    val counterEnabled: Boolean = true,
    val counterSide: CounterSide = CounterSide.LEFT,
    val counterGapDp: Int = 10,
    val buttonScale: Float = 1.0f,
    val buttonRadiusSameAsCard: Boolean = true,
    val buttonRadiusDp: Int = 12,
    val buttonColor: Int = 0xFF1B3A6B.toInt(),
    val buttonOpacityPercent: Int = 62,
    val plusColor: Int = 0xFFFFFFFF.toInt(),
    // Counter number
    val showNumber: Boolean = true,
    val numberScale: Float = 0.8f,
    val numberGapDp: Int = 2,
    val numberColor: Int = 0xFF0E1E3C.toInt(),
)
