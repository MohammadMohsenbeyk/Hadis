package ir.wexipe.ayahwidget.layout

/**
 * Where a kashida (tatweel, U+0640) may be inserted in an Arabic/Persian word without breaking it:
 * only between two letters that both connect, and after any diacritics of the first letter.
 * Never before/after letters that do not connect (ا د ذ ر ز و ...), never at the word edges.
 */
object Kashida {
    const val TATWEEL = '\u0640'

    private val DUAL_JOINING: Set<Char> =
        "بتثجحخسشصضطظعغفقكلمنهيئیکگپچ".toSet()

    private fun isMark(c: Char): Boolean =
        c in '\u064B'..'\u065F' || c == '\u0670' || c in '\u06D6'..'\u06ED'

    /** Indices (in the original word) before which a tatweel can be inserted. */
    fun positions(word: String): List<Int> {
        val out = ArrayList<Int>()
        for (i in word.indices) {
            if (word[i] !in DUAL_JOINING) continue
            var j = i + 1
            while (j < word.length && isMark(word[j])) j++
            if (j < word.length && word[j] in DUAL_JOINING) out.add(j)
        }
        return out
    }

    /** The insertion point closest to the middle of the word, or -1 when there is none. */
    fun bestPosition(word: String): Int {
        val p = positions(word)
        if (p.isEmpty()) return -1
        val mid = word.length / 2f
        return p.minByOrNull { kotlin.math.abs(it - mid) } ?: -1
    }

    fun insert(word: String, position: Int): String =
        word.substring(0, position) + TATWEEL + word.substring(position)
}
