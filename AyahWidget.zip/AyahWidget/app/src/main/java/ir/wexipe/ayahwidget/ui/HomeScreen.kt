package ir.wexipe.ayahwidget.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.wexipe.ayahwidget.ui.components.AppIcons
import ir.wexipe.ayahwidget.ui.components.ButtonState
import ir.wexipe.ayahwidget.ui.components.SecondaryButton
import ir.wexipe.ayahwidget.ui.components.StatefulPrimaryButton
import ir.wexipe.ayahwidget.ui.sections.ButtonTab
import ir.wexipe.ayahwidget.ui.sections.ContentTab
import ir.wexipe.ayahwidget.ui.sections.StyleTab
import ir.wexipe.ayahwidget.ui.sections.TextTab
import ir.wexipe.ayahwidget.ui.sections.WidgetTab
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val colors = AppTheme.colors
    val draft by vm.draft.collectAsStateWithLifecycle()
    val saved by vm.saved.collectAsStateWithLifecycle()
    val autoApply by vm.autoApply.collectAsStateWithLifecycle()
    val applyState by vm.applyState.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    val activeId by vm.activeId.collectAsStateWithLifecycle()
    val presets by vm.presets.collectAsStateWithLifecycle()
    val widgetSize by vm.widgetSize.collectAsStateWithLifecycle()
    val dirty = draft != saved

    val active = texts.firstOrNull { it.id == activeId } ?: texts.first()

    var tab by rememberSaveable { mutableStateOf(SettingsTab.CONTENT) }
    var previewSize by rememberSaveable { mutableStateOf(PreviewSize.ACTUAL) }
    val snackbar = remember { SnackbarHostState() }
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    // The widget on the home screen may have been tapped or resized while the app was closed.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    LaunchedEffect(Unit) {
        vm.events.collect { message ->
            snackbar.currentSnackbarData?.dismiss()
            launch { snackbar.showSnackbar(message) }
        }
    }

    // ACTUAL needs a remembered widget size; fall back to the 4x1 grid size until a widget exists.
    val shownSize = if (previewSize == PreviewSize.ACTUAL && widgetSize == null) PreviewSize.X4_1 else previewSize

    Box(
        Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .imePadding()
        ) {
            TopBar(
                dirty = dirty,
                previewLabel = shownSize.label,
                onCycleSize = { previewSize = shownSize.next(widgetSize != null) },
            )
            PreviewStage(
                style = draft,
                text = active.text,
                counter = active.counter,
                previewSize = shownSize,
                actualSize = widgetSize,
                onIncrement = vm::incrementActive,
            )
            Spacer(Modifier.height(12.dp))
            SettingsTabBar(selected = tab, onSelect = { tab = it })
            Spacer(Modifier.height(4.dp))

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Crossfade(targetState = tab, animationSpec = tween(180), label = "tab") { current ->
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        when (current) {
                            SettingsTab.CONTENT -> ContentTab(
                                texts = texts,
                                activeId = activeId,
                                onSelect = vm::selectText,
                                onCreate = vm::createText,
                                onUpdate = vm::updateText,
                                onDelete = vm::deleteText,
                                onResetCounter = vm::resetCounter,
                            )
                            SettingsTab.STYLE -> StyleTab(
                                draft = draft,
                                presets = presets,
                                autoApply = autoApply,
                                onApplyPreset = vm::applyPreset,
                                onSavePreset = vm::savePreset,
                                onDeletePreset = vm::deletePreset,
                                onResetStyle = vm::resetStyle,
                                onAutoApplyChange = vm::setAutoApply,
                            )
                            SettingsTab.TEXT -> TextTab(draft, vm::update)
                            SettingsTab.WIDGET -> WidgetTab(draft, vm::update)
                            SettingsTab.BUTTON -> ButtonTab(draft, vm::update)
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !imeVisible,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                BottomBar(
                    dirty = dirty,
                    applyState = applyState,
                    onApply = vm::applyChanges,
                    onCancel = vm::cancelChanges,
                )
            }
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 92.dp),
            snackbar = { data ->
                Row(
                    Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Radius.control))
                        .background(colors.primary)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        AppIcons.Check,
                        contentDescription = null,
                        tint = colors.onPrimary,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        data.visuals.message,
                        style = AppTheme.typography.settingTitle,
                        color = colors.onPrimary,
                    )
                }
            },
        )
    }
}

/** Slim top bar: the app name, an unsaved marker and the preview-size switch. */
@Composable
private fun TopBar(dirty: Boolean, previewLabel: String, onCycleSize: () -> Unit) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("AyehWidget", style = type.appTitle, color = colors.textPrimary)
        Spacer(Modifier.width(10.dp))
        AnimatedVisibility(visible = dirty, enter = fadeIn(tween(150)), exit = fadeOut(tween(150))) {
            Text(
                "ذخیره‌نشده",
                style = type.caption,
                color = colors.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(percent = 50))
                    .background(colors.primaryContainer)
                    .padding(horizontal = 10.dp, vertical = 3.dp),
            )
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier
                .height(40.dp)
                .clip(RoundedCornerShape(percent = 50))
                .background(colors.surface)
                .border(1.dp, colors.border, RoundedCornerShape(percent = 50))
                .clickable(role = Role.Button, onClick = onCycleSize)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(AppIcons.Size, contentDescription = "اندازهٔ پیش‌نمایش", tint = colors.primary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(previewLabel, style = type.value, color = colors.primary)
        }
    }
}

@Composable
private fun BottomBar(
    dirty: Boolean,
    applyState: ButtonState,
    onApply: () -> Unit,
    onCancel: () -> Unit,
) {
    val colors = AppTheme.colors
    Column(
        Modifier
            .fillMaxWidth()
            .background(colors.surface)
            .navigationBarsPadding()
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(colors.border)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StatefulPrimaryButton(
                text = "اعمال تنظیمات",
                successText = "اعمال شد",
                state = applyState,
                enabled = dirty,
                onClick = onApply,
                modifier = Modifier.weight(1f),
                icon = AppIcons.Check,
            )
            AnimatedVisibility(
                visible = dirty,
                enter = fadeIn(tween(160)) + expandHorizontally(tween(200)),
                exit = fadeOut(tween(120)) + shrinkHorizontally(tween(160)),
            ) {
                Row {
                    Spacer(Modifier.width(10.dp))
                    SecondaryButton(text = "لغو", onClick = onCancel, modifier = Modifier.width(88.dp))
                }
            }
        }
    }
}
