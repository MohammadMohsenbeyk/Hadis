package ir.wexipe.ayahwidget.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius

/** Quiet round icon button (44dp touch target). */
@Composable
fun IconAction(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tint: Color = AppTheme.colors.textSecondary,
) {
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (enabled) tint else AppTheme.colors.textDisabled,
            modifier = Modifier.size(20.dp),
        )
    }
}

/** Selection dot used for the active text / active style. */
@Composable
fun SelectDot(selected: Boolean, modifier: Modifier = Modifier) {
    val colors = AppTheme.colors
    val bg by animateColorAsState(if (selected) colors.accent else Color.Transparent, tween(160), label = "dot")
    val border by animateColorAsState(if (selected) colors.accent else colors.borderStrong, tween(160), label = "dotBorder")
    Box(
        modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(bg)
            .border(1.5.dp, border, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(AppIcons.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
        }
    }
}

/** Small pill that shows a number (always left-to-right). */
@Composable
fun CountChip(text: String, modifier: Modifier = Modifier) {
    val colors = AppTheme.colors
    Box(
        modifier
            .clip(RoundedCornerShape(percent = 50))
            .background(colors.primaryContainer)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = AppTheme.typography.value, color = colors.primary)
    }
}

/** Single-line text field in the same visual language as the verse editor. */
@Composable
fun SimpleTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    errorMessage: String? = null,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    val shape = RoundedCornerShape(Radius.control)
    var focused by remember { mutableStateOf(false) }
    val isError = errorMessage != null
    val borderColor by animateColorAsState(
        when {
            isError -> colors.danger
            focused -> colors.accent
            else -> colors.border
        },
        tween(150), label = "nameBorder"
    )
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused },
            textStyle = type.settingTitle.copy(color = colors.textPrimary),
            cursorBrush = SolidColor(if (isError) colors.danger else colors.accent),
            decorationBox = { inner ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(shape)
                        .background(if (isError) colors.dangerContainer else colors.surface)
                        .border(if (focused || isError) 1.5.dp else 1.dp, borderColor, shape)
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    if (value.isEmpty()) {
                        Text(placeholder, style = type.settingTitle, color = colors.textDisabled)
                    }
                    inner()
                }
            },
        )
        if (errorMessage != null) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                Icon(AppIcons.Alert, contentDescription = null, tint = colors.danger, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(errorMessage, style = type.caption, color = colors.danger)
            }
        }
    }
}
