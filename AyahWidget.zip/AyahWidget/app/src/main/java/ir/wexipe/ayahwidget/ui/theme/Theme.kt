package ir.wexipe.ayahwidget.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.LayoutDirection
import ir.wexipe.ayahwidget.widget.AppFont
import ir.wexipe.ayahwidget.widget.FontProvider

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val typography = remember(context) {
        buildTypography(
            thin = FontFamily(FontProvider.typeface(context, AppFont.THIN)),
            medium = FontFamily(FontProvider.typeface(context, AppFont.MEDIUM)),
            bold = FontFamily(FontProvider.typeface(context, AppFont.BOLD)),
        )
    }
    val colors = LightAppColors
    val scheme = lightColorScheme(
        primary = colors.primary,
        onPrimary = colors.onPrimary,
        background = colors.background,
        onBackground = colors.textPrimary,
        surface = colors.surface,
        onSurface = colors.textPrimary,
        outline = colors.border,
    )

    // The whole UI is real RTL (Persian/Arabic). Numeric widgets opt out locally.
    CompositionLocalProvider(
        LocalAppColors provides colors,
        LocalAppTypography provides typography,
        LocalLayoutDirection provides LayoutDirection.Rtl,
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

object AppTheme {
    val colors: AppColors
        @Composable @ReadOnlyComposable get() = LocalAppColors.current
    val typography: AppTypography
        @Composable @ReadOnlyComposable get() = LocalAppTypography.current
}
