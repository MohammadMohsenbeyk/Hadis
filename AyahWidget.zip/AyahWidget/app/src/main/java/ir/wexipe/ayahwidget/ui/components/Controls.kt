package ir.wexipe.ayahwidget.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius

data class SegmentOption<T>(val value: T, val label: String, val icon: ImageVector? = null)

/** Segmented selector with an animated sliding indicator. Selected state = solid navy. */
@Composable
fun <T> SegmentedControl(
    options: List<SegmentOption<T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 46.dp,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    val outer = RoundedCornerShape(Radius.control)
    val inner = RoundedCornerShape(Radius.control - 3.dp)
    val selectedIndex = options.indexOfFirst { it.value == selected }.coerceAtLeast(0)

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(outer)
            .background(colors.surfaceTint)
            .border(1.dp, colors.border, outer)
            .padding(3.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorX by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = tween(220, easing = FastOutSlowInEasing),
            label = "segment",
        )

        // offset() is layout-direction aware, so index 0 sits on the right in RTL.
        Box(
            Modifier
                .offset(x = indicatorX)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, inner)
                .clip(inner)
                .background(colors.primary)
        )

        Row(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight()
        ) {
            options.forEach { option ->
                val isSelected = option.value == selected
                val fg by animateColorAsState(
                    if (isSelected) colors.onPrimary else colors.textSecondary,
                    tween(180), label = "segmentText"
                )
                Row(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(inner)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            role = Role.RadioButton,
                        ) { onSelect(option.value) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (option.icon != null) {
                        Icon(option.icon, contentDescription = null, tint = fg, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(option.label, style = type.buttonSmall, color = fg)
                }
            }
        }
    }
}

/** A titled segmented selector, padded to sit inside a SettingsGroup. */
@Composable
fun <T> SegmentedSetting(
    title: String,
    options: List<SegmentOption<T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        SettingHeader(title = title)
        SegmentedControl(options = options, selected = selected, onSelect = onSelect)
    }
}

@Composable
fun SwitchSetting(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    description: String? = null,
) {
    val colors = AppTheme.colors
    Row(
        modifier
            .fillMaxWidth()
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = AppTheme.typography.settingTitle, color = colors.textPrimary)
            if (description != null) {
                Text(description, style = AppTheme.typography.description, color = colors.textSecondary)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = colors.accent,
                checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = colors.borderStrong,
                uncheckedBorderColor = Color.Transparent,
            ),
        )
    }
}

/**
 * Multi-line verse editor. Direction follows the content (Arabic = right-to-left).
 * States: default, focused (accent border), error (red border + message).
 */
@Composable
fun VerseTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    errorMessage: String? = null,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    val shape = RoundedCornerShape(Radius.control)
    var focused by remember { mutableStateOf(false) }
    val isError = errorMessage != null
    val borderColor by animateColorAsState(
        when {
            isError -> colors.danger
            focused -> colors.accent
            else -> colors.border
        },
        tween(150), label = "fieldBorder"
    )

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused },
            textStyle = type.verse.copy(color = colors.textPrimary),
            cursorBrush = SolidColor(if (isError) colors.danger else colors.accent),
            minLines = 4,
            decorationBox = { innerTextField ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(if (isError) colors.dangerContainer else colors.surface)
                        .border(if (focused || isError) 1.5.dp else 1.dp, borderColor, shape)
                        .padding(14.dp)
                ) {
                    if (value.isEmpty()) {
                        Text(placeholder, style = type.verse, color = colors.textDisabled)
                    }
                    innerTextField()
                }
            },
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedVisibility(visible = isError) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        AppIcons.Alert,
                        contentDescription = null,
                        tint = colors.danger,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(errorMessage ?: "", style = type.caption, color = colors.danger)
                }
            }
            Spacer(Modifier.weight(1f))
            Text(value.length.toString(), style = type.value, color = colors.textSecondary)
        }
    }
}
