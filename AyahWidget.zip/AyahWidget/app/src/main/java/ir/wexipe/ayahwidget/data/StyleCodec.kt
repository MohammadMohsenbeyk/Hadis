package ir.wexipe.ayahwidget.data

import ir.wexipe.ayahwidget.widget.AppFont

/**
 * One compact string per style ("key=value|key=value"). Used for the active style and for every
 * saved preset, so there is a single serialisation path. Unknown or broken keys fall back to the
 * default, which also makes future additions to WidgetStyle backward compatible.
 */
object StyleCodec {

    fun encode(s: WidgetStyle): String = listOf(
        "font" to s.font.key,
        "size" to s.fontSizeSp,
        "minSize" to s.minFontSizeSp,
        "scaleX" to s.textScaleX,
        "minScaleX" to s.minTextScaleX,
        "line" to s.lineSpacing,
        "letter" to s.letterSpacingEm,
        "lines" to s.preferredLines,
        "equal" to s.equalLines,
        "textColor" to s.textColor,
        "bgColor" to s.bgColor,
        "bgOpacity" to s.bgOpacityPercent,
        "radius" to s.cornerRadiusDp,
        "width" to s.widthPercent,
        "height" to s.heightPercent,
        "autoHeight" to s.autoHeight,
        "margin" to s.marginDp,
        "padTop" to s.paddingTopDp,
        "padBottom" to s.paddingBottomDp,
        "padStart" to s.paddingStartDp,
        "padEnd" to s.paddingEndDp,
        "hAlign" to s.hAlign.name,
        "vAlign" to s.vAlign.name,
        "counter" to s.counterEnabled,
        "side" to s.counterSide.name,
        "counterGap" to s.counterGapDp,
        "btnScale" to s.buttonScale,
        "btnSame" to s.buttonRadiusSameAsCard,
        "btnRadius" to s.buttonRadiusDp,
        "btnColor" to s.buttonColor,
        "btnOpacity" to s.buttonOpacityPercent,
        "plusColor" to s.plusColor,
        "number" to s.showNumber,
        "numScale" to s.numberScale,
        "numGap" to s.numberGapDp,
        "numColor" to s.numberColor,
    ).joinToString("|") { "${it.first}=${it.second}" }

    fun decode(raw: String?): WidgetStyle {
        var s = WidgetStyle()
        if (raw.isNullOrBlank()) return s
        for (pair in raw.split("|")) {
            val i = pair.indexOf('=')
            if (i <= 0) continue
            val k = pair.substring(0, i)
            val v = pair.substring(i + 1)
            s = apply(s, k, v)
        }
        return s
    }

    private fun apply(s: WidgetStyle, k: String, v: String): WidgetStyle {
        fun f(range: ClosedFloatingPointRange<Float>, current: Float) =
            v.toFloatOrNull()?.coerceIn(range) ?: current
        fun n(range: IntRange, current: Int) = v.toIntOrNull()?.coerceIn(range) ?: current
        fun b(current: Boolean) = v.toBooleanStrictOrNull() ?: current
        fun c(current: Int) = v.toIntOrNull() ?: current
        return when (k) {
            "font" -> s.copy(font = AppFont.fromKey(v))
            "size" -> s.copy(fontSizeSp = f(Limits.fontSize, s.fontSizeSp))
            "minSize" -> s.copy(minFontSizeSp = f(Limits.minFontSize, s.minFontSizeSp))
            "scaleX" -> s.copy(textScaleX = f(Limits.textScaleX, s.textScaleX))
            "minScaleX" -> s.copy(minTextScaleX = f(Limits.minTextScaleX, s.minTextScaleX))
            "line" -> s.copy(lineSpacing = f(Limits.lineSpacing, s.lineSpacing))
            "letter" -> s.copy(letterSpacingEm = f(Limits.letterSpacing, s.letterSpacingEm))
            "lines" -> s.copy(preferredLines = n(Limits.preferredLines, s.preferredLines))
            "equal" -> s.copy(equalLines = b(s.equalLines))
            "textColor" -> s.copy(textColor = c(s.textColor))
            "bgColor" -> s.copy(bgColor = c(s.bgColor))
            "bgOpacity" -> s.copy(bgOpacityPercent = n(Limits.opacity, s.bgOpacityPercent))
            "radius" -> s.copy(cornerRadiusDp = n(Limits.cornerRadius, s.cornerRadiusDp))
            "width" -> s.copy(widthPercent = n(Limits.sizePercent, s.widthPercent))
            "height" -> s.copy(heightPercent = n(Limits.sizePercent, s.heightPercent))
            "autoHeight" -> s.copy(autoHeight = b(s.autoHeight))
            "margin" -> s.copy(marginDp = n(Limits.margin, s.marginDp))
            "padTop" -> s.copy(paddingTopDp = n(Limits.padding, s.paddingTopDp))
            "padBottom" -> s.copy(paddingBottomDp = n(Limits.padding, s.paddingBottomDp))
            "padStart" -> s.copy(paddingStartDp = n(Limits.padding, s.paddingStartDp))
            "padEnd" -> s.copy(paddingEndDp = n(Limits.padding, s.paddingEndDp))
            "hAlign" -> s.copy(hAlign = HAlign.values().firstOrNull { it.name == v } ?: s.hAlign)
            "vAlign" -> s.copy(vAlign = VAlign.values().firstOrNull { it.name == v } ?: s.vAlign)
            "counter" -> s.copy(counterEnabled = b(s.counterEnabled))
            "side" -> s.copy(counterSide = CounterSide.values().firstOrNull { it.name == v } ?: s.counterSide)
            "counterGap" -> s.copy(counterGapDp = n(Limits.counterGap, s.counterGapDp))
            "btnScale" -> s.copy(buttonScale = f(Limits.buttonScale, s.buttonScale))
            "btnSame" -> s.copy(buttonRadiusSameAsCard = b(s.buttonRadiusSameAsCard))
            "btnRadius" -> s.copy(buttonRadiusDp = n(Limits.buttonRadius, s.buttonRadiusDp))
            "btnColor" -> s.copy(buttonColor = c(s.buttonColor))
            "btnOpacity" -> s.copy(buttonOpacityPercent = n(Limits.opacity, s.buttonOpacityPercent))
            "plusColor" -> s.copy(plusColor = c(s.plusColor))
            "number" -> s.copy(showNumber = b(s.showNumber))
            "numScale" -> s.copy(numberScale = f(Limits.numberScale, s.numberScale))
            "numGap" -> s.copy(numberGapDp = n(Limits.numberGap, s.numberGapDp))
            "numColor" -> s.copy(numberColor = c(s.numberColor))
            else -> s
        }
    }
}
