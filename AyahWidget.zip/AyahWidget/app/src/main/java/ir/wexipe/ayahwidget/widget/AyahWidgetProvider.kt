package ir.wexipe.ayahwidget.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.RemoteViews
import ir.wexipe.ayahwidget.MainActivity
import ir.wexipe.ayahwidget.R
import ir.wexipe.ayahwidget.data.SettingsRepository
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class AyahWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_INCREMENT) {
            handleIncrement(context)
        } else {
            super.onReceive(context, intent)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, manager, it, pressed = false) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle,
    ) {
        // The user resized the widget: re-plan the layout for the new size.
        updateWidget(context, manager, appWidgetId, pressed = false)
    }

    /** One tap on "+": count it, flash the pressed state for a moment, then draw the normal state. */
    private fun handleIncrement(context: Context) {
        val repo = SettingsRepository(context)
        if (!repo.loadStyle().counterEnabled) return
        repo.incrementActiveCounter()
        val pending = goAsync()
        updateAll(context, pressed = true)
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                updateAll(context, pressed = false)
            } finally {
                pending.finish()
            }
        }, PRESS_FLASH_MS)
    }

    companion object {
        const val ACTION_INCREMENT = "ir.wexipe.ayahwidget.ACTION_INCREMENT"
        private const val PRESS_FLASH_MS = 140L
        private const val DEFAULT_WIDTH_DP = 250
        private const val DEFAULT_HEIGHT_DP = 72
        private const val MIN_TOUCH_DP = 52f

        /** Re-renders every placed widget. Returns how many widgets were updated. */
        fun updateAll(context: Context, pressed: Boolean = false): Int {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, AyahWidgetProvider::class.java))
            ids.forEach { updateWidget(context, manager, it, pressed) }
            return ids.size
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int, pressed: Boolean) {
            val repo = SettingsRepository(context)
            val style = repo.loadStyle()
            val active = repo.activeText()
            val density = context.resources.displayMetrics.density
            val options = manager.getAppWidgetOptions(appWidgetId)

            // Real size reported by the launcher (portrait: min width / max height).
            val portrait = context.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
            val w = options.getInt(
                if (portrait) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH
                else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0
            )
            val h = options.getInt(
                if (portrait) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT
                else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0
            )
            val widthDp = (if (w > 0) w else DEFAULT_WIDTH_DP).toFloat()
            val heightDp = (if (h > 0) h else DEFAULT_HEIGHT_DP).toFloat()
            // The app previews at exactly this size, so preview and widget use the same layout.
            repo.saveWidgetSize(widthDp, heightDp)

            val views = RemoteViews(context.packageName, R.layout.widget_ayah)
            try {
                val card = WidgetRenderer.render(context, style, active.text, active.counter, widthDp, heightDp, pressed)
                views.setImageViewBitmap(R.id.widget_image, card.bitmap)
                views.setContentDescription(R.id.widget_image, active.text)

                val button = card.buttonDp
                if (style.counterEnabled && button != null) {
                    // Invisible touch area that sits exactly over the button (at least 52dp).
                    val halfW = max(button.w, MIN_TOUCH_DP) / 2f
                    val halfH = max(button.h, MIN_TOUCH_DP) / 2f
                    val l = max(0f, button.cx - halfW)
                    val r = min(widthDp, button.cx + halfW)
                    val t = max(0f, button.cy - halfH)
                    val b = min(heightDp, button.cy + halfH)
                    views.setViewVisibility(R.id.counter_zone, View.VISIBLE)
                    views.setViewPadding(
                        R.id.counter_zone,
                        (l * density).roundToInt(),
                        (t * density).roundToInt(),
                        ((widthDp - r) * density).roundToInt(),
                        ((heightDp - b) * density).roundToInt(),
                    )
                    views.setOnClickPendingIntent(R.id.counter_hit, incrementIntent(context))
                    views.setContentDescription(R.id.counter_hit, "Add one")
                } else {
                    views.setViewVisibility(R.id.counter_zone, View.GONE)
                }
            } catch (e: Exception) {
                views.setViewVisibility(R.id.counter_zone, View.GONE)
            }

            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            views.setOnClickPendingIntent(
                R.id.widget_root,
                PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            )
            manager.updateAppWidget(appWidgetId, views)
        }

        private fun incrementIntent(context: Context): PendingIntent {
            val intent = Intent(context, AyahWidgetProvider::class.java).setAction(ACTION_INCREMENT)
            return PendingIntent.getBroadcast(
                context, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
