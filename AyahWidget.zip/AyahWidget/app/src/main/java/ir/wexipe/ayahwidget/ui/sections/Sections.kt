package ir.wexipe.ayahwidget.ui.sections

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.wexipe.ayahwidget.data.CounterSide
import ir.wexipe.ayahwidget.data.HAlign
import ir.wexipe.ayahwidget.data.Limits
import ir.wexipe.ayahwidget.data.StylePreset
import ir.wexipe.ayahwidget.data.TextItem
import ir.wexipe.ayahwidget.data.VAlign
import ir.wexipe.ayahwidget.data.WidgetStyle
import ir.wexipe.ayahwidget.data.formatCount
import ir.wexipe.ayahwidget.ui.components.AppIcons
import ir.wexipe.ayahwidget.ui.components.ColorRow
import ir.wexipe.ayahwidget.ui.components.ConfirmDialog
import ir.wexipe.ayahwidget.ui.components.CountChip
import ir.wexipe.ayahwidget.ui.components.GroupDivider
import ir.wexipe.ayahwidget.ui.components.GroupHeader
import ir.wexipe.ayahwidget.ui.components.IconAction
import ir.wexipe.ayahwidget.ui.components.PresetNameDialog
import ir.wexipe.ayahwidget.ui.components.SecondaryButton
import ir.wexipe.ayahwidget.ui.components.SegmentOption
import ir.wexipe.ayahwidget.ui.components.SegmentedSetting
import ir.wexipe.ayahwidget.ui.components.SelectDot
import ir.wexipe.ayahwidget.ui.components.SettingsGroup
import ir.wexipe.ayahwidget.ui.components.SliderSetting
import ir.wexipe.ayahwidget.ui.components.SwitchSetting
import ir.wexipe.ayahwidget.ui.components.TextEditorDialog
import ir.wexipe.ayahwidget.ui.components.TonalButton
import ir.wexipe.ayahwidget.ui.components.toFloatRange
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius
import ir.wexipe.ayahwidget.widget.AppFont
import ir.wexipe.ayahwidget.widget.FontProvider
import ir.wexipe.ayahwidget.widget.WidgetRenderer

/** Every control edits the draft style through this function: update { it.copy(...) }. */
typealias Updater = ((WidgetStyle) -> WidgetStyle) -> Unit

private fun argb(hex: Long): Int = (0xFF000000 or hex).toInt()

private val TextPresets = listOf(
    argb(0x0E1E3C), argb(0x1B3A6B), argb(0x000000), argb(0xFFFFFF),
    argb(0xC9A24B), argb(0x2E7D5B), argb(0x7A1F3D),
)
private val BackgroundPresets = listOf(
    argb(0xE3F1FF), argb(0xFFFFFF), argb(0xF2F5FB), argb(0xFFF8E7),
    argb(0xE6F2EC), argb(0x1B3A6B), argb(0x0E1E3C),
)
private val ButtonPresets = listOf(
    argb(0x1B3A6B), argb(0x0E1E3C), argb(0x3563C4), argb(0x2E7D5B),
    argb(0x7A1F3D), argb(0xC9A24B), argb(0x000000),
)

// ====================================================================== CONTENT

@Composable
fun ContentTab(
    texts: List<TextItem>,
    activeId: String,
    onSelect: (String) -> Unit,
    onCreate: (String) -> Unit,
    onUpdate: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    onResetCounter: (String) -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf<String?>(null) }
    var resetId by remember { mutableStateOf<String?>(null) }

    GroupHeader(
        title = "متن‌ها",
        icon = AppIcons.Book,
        action = {
            TonalButton(text = "متن جدید", icon = AppIcons.Plus, onClick = { creating = true })
        },
    )
    SettingsGroup {
        texts.forEachIndexed { index, item ->
            if (index > 0) GroupDivider()
            TextRow(
                item = item,
                active = item.id == activeId,
                onSelect = { onSelect(item.id) },
                onReset = { resetId = item.id },
                onSettings = { editingId = item.id },
            )
        }
    }

    if (creating) {
        TextEditorDialog(
            title = "متن جدید",
            initialText = "",
            counter = null,
            canDelete = false,
            onSave = {
                onCreate(it)
                creating = false
            },
            onResetCounter = {},
            onDelete = {},
            onDismiss = { creating = false },
        )
    }

    val editing = texts.firstOrNull { it.id == editingId }
    if (editing != null) {
        TextEditorDialog(
            title = "تنظیمات متن",
            initialText = editing.text,
            counter = editing.counter,
            canDelete = !editing.builtIn,
            onSave = {
                onUpdate(editing.id, it)
                editingId = null
            },
            onResetCounter = { onResetCounter(editing.id) },
            onDelete = {
                onDelete(editing.id)
                editingId = null
            },
            onDismiss = { editingId = null },
        )
    }

    val resetting = texts.firstOrNull { it.id == resetId }
    if (resetting != null) {
        ConfirmDialog(
            title = "صفر کردن شمارنده؟",
            message = "شمارندهٔ «" + resetting.title(24) + "» پاک می‌شود و قابل بازگشت نیست.",
            confirmText = "صفر کن",
            cancelText = "انصراف",
            onConfirm = {
                onResetCounter(resetting.id)
                resetId = null
            },
            onDismiss = { resetId = null },
        )
    }
}

@Composable
private fun TextRow(
    item: TextItem,
    active: Boolean,
    onSelect: () -> Unit,
    onReset: () -> Unit,
    onSettings: () -> Unit,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.RadioButton, onClick = onSelect)
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SelectDot(selected = active)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.title(),
                style = type.settingTitle.copy(textDirection = TextDirection.ContentOrRtl),
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (item.builtIn) "پیشنهادی" else "ساخته‌شده",
                style = type.caption,
                color = colors.textSecondary,
            )
        }
        Spacer(Modifier.width(8.dp))
        CountChip(formatCount(item.counter, WidgetRenderer.isRtl(item.text)))
        IconAction(AppIcons.Refresh, "صفر کردن شمارنده", onReset, enabled = item.counter > 0)
        IconAction(AppIcons.Pen, "تنظیمات متن", onSettings)
    }
}

// ====================================================================== STYLE (presets)

@Composable
fun StyleTab(
    draft: WidgetStyle,
    presets: List<StylePreset>,
    autoApply: Boolean,
    onApplyPreset: (WidgetStyle) -> Unit,
    onSavePreset: (String) -> Unit,
    onDeletePreset: (String) -> Unit,
    onResetStyle: () -> Unit,
    onAutoApplyChange: (Boolean) -> Unit,
) {
    var naming by remember { mutableStateOf(false) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    val defaultStyle = remember { WidgetStyle() }

    GroupHeader(
        title = "استایل‌ها",
        icon = AppIcons.Droplet,
        action = {
            TonalButton(text = "ذخیرهٔ استایل فعلی", icon = AppIcons.Plus, onClick = { naming = true })
        },
    )
    SettingsGroup {
        PresetRow(
            name = "استایل پیش‌فرض",
            active = draft == defaultStyle,
            onSelect = { onApplyPreset(defaultStyle) },
            onDelete = null,
        )
        presets.forEach { preset ->
            GroupDivider()
            PresetRow(
                name = preset.name,
                active = draft == preset.style,
                onSelect = { onApplyPreset(preset.style) },
                onDelete = { deleteId = preset.id },
            )
        }
    }

    SecondaryButton(
        text = "بازنشانی به پیش‌فرض",
        icon = AppIcons.Refresh,
        enabled = draft != defaultStyle,
        onClick = onResetStyle,
        modifier = Modifier.fillMaxWidth(),
    )

    SettingsGroup {
        SwitchSetting(
            title = "به‌روزرسانی خودکار ویجت",
            checked = autoApply,
            onCheckedChange = onAutoApplyChange,
        )
    }

    if (naming) {
        PresetNameDialog(
            onSave = {
                onSavePreset(it)
                naming = false
            },
            onDismiss = { naming = false },
        )
    }
    val deleting = presets.firstOrNull { it.id == deleteId }
    if (deleting != null) {
        ConfirmDialog(
            title = "حذف استایل؟",
            message = "استایل «" + deleting.name + "» حذف می‌شود. متن‌ها و شمارنده‌ها تغییری نمی‌کنند.",
            confirmText = "حذف",
            cancelText = "انصراف",
            onConfirm = {
                onDeletePreset(deleting.id)
                deleteId = null
            },
            onDismiss = { deleteId = null },
        )
    }
}

@Composable
private fun PresetRow(name: String, active: Boolean, onSelect: () -> Unit, onDelete: (() -> Unit)?) {
    val colors = AppTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.RadioButton, onClick = onSelect)
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SelectDot(selected = active)
        Spacer(Modifier.width(12.dp))
        Text(
            name,
            style = AppTheme.typography.settingTitle,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (onDelete != null) {
            IconAction(AppIcons.Trash, "حذف استایل", onDelete)
        } else {
            Spacer(Modifier.width(44.dp))
        }
    }
}

// ====================================================================== TEXT

@Composable
fun TextTab(s: WidgetStyle, update: Updater) {
    val context = LocalContext.current
    GroupHeader(title = "فونت", icon = AppIcons.Type)
    SettingsGroup {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AppFont.values().forEach { font ->
                FontOptionCard(
                    font = font,
                    selected = s.font == font,
                    available = remember(font) { FontProvider.isCustomAvailable(context, font) },
                    onClick = { update { it.copy(font = font) } },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        GroupDivider()
        ColorRow(
            title = "رنگ متن",
            color = s.textColor,
            presets = TextPresets,
            onColorChange = { c -> update { it.copy(textColor = c) } },
        )
    }

    GroupHeader(title = "اندازه و خطوط", icon = AppIcons.TextStyle)
    SettingsGroup {
        SegmentedSetting(
            title = "تعداد خط",
            options = Limits.preferredLines.map { SegmentOption(it, it.toString()) },
            selected = s.preferredLines,
            onSelect = { v -> update { it.copy(preferredLines = v) } },
        )
        GroupDivider()
        SwitchSetting(
            title = "هم‌اندازه کردن طول خطوط",
            checked = s.equalLines,
            onCheckedChange = { v -> update { it.copy(equalLines = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حداکثر اندازه متن",
            value = s.fontSizeSp,
            range = Limits.fontSize,
            step = 0.5f,
            decimals = 1,
            unit = " sp",
            onValueChange = { v -> update { it.copy(fontSizeSp = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حداقل اندازهٔ خوانا",
            value = s.minFontSizeSp,
            range = Limits.minFontSize,
            step = 0.5f,
            decimals = 1,
            unit = " sp",
            onValueChange = { v -> update { it.copy(minFontSizeSp = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "مقیاس افقی حروف",
            value = s.textScaleX,
            range = Limits.textScaleX,
            step = 0.01f,
            decimals = 2,
            unit = "×",
            onValueChange = { v -> update { it.copy(textScaleX = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حداقل مقیاس افقی",
            value = s.minTextScaleX,
            range = Limits.minTextScaleX,
            step = 0.01f,
            decimals = 2,
            unit = "×",
            onValueChange = { v -> update { it.copy(minTextScaleX = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "فاصلهٔ خطوط",
            value = s.lineSpacing,
            range = Limits.lineSpacing,
            step = 0.05f,
            decimals = 2,
            unit = "×",
            onValueChange = { v -> update { it.copy(lineSpacing = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "فاصلهٔ حروف",
            value = s.letterSpacingEm,
            range = Limits.letterSpacing,
            step = 0.01f,
            decimals = 2,
            unit = " em",
            onValueChange = { v -> update { it.copy(letterSpacingEm = v) } },
        )
    }
}

@Composable
private fun FontOptionCard(
    font: AppFont,
    selected: Boolean,
    available: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    val context = LocalContext.current
    val shape = RoundedCornerShape(Radius.control)
    val border by animateColorAsState(
        if (selected) colors.accent else colors.border, tween(160), label = "fontBorder"
    )
    val bg by animateColorAsState(
        if (selected) colors.primaryContainer else colors.surfaceTint, tween(160), label = "fontBg"
    )
    val family = remember(font) { FontFamily(FontProvider.typeface(context, font)) }

    Column(
        modifier
            .clip(shape)
            .background(bg)
            .border(if (selected) 2.dp else 1.dp, border, shape)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            "وَمَنْ",
            style = TextStyle(fontFamily = family, fontSize = 22.sp, lineHeight = 38.sp, color = colors.textPrimary),
        )
        Text(font.label, style = type.settingTitle, color = if (selected) colors.primary else colors.textPrimary)
        Text(
            if (available) font.englishName else "فایل یافت نشد",
            style = type.caption,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
    }
}

// ====================================================================== WIDGET

@Composable
fun WidgetTab(s: WidgetStyle, update: Updater) {
    val horizontal = listOf(
        SegmentOption(HAlign.RIGHT, "راست", AppIcons.AlignRight),
        SegmentOption(HAlign.CENTER, "وسط", AppIcons.AlignCenter),
        SegmentOption(HAlign.LEFT, "چپ", AppIcons.AlignLeft),
    )
    val vertical = listOf(
        SegmentOption(VAlign.TOP, "بالا", AppIcons.VTop),
        SegmentOption(VAlign.CENTER, "وسط", AppIcons.VCenter),
        SegmentOption(VAlign.BOTTOM, "پایین", AppIcons.VBottom),
    )

    GroupHeader(title = "پس‌زمینه", icon = AppIcons.Card)
    SettingsGroup {
        ColorRow(
            title = "رنگ پس‌زمینه",
            color = s.bgColor,
            presets = BackgroundPresets,
            onColorChange = { c -> update { it.copy(bgColor = c) } },
        )
        GroupDivider()
        SliderSetting(
            title = "شفافیت پس‌زمینه",
            value = s.bgOpacityPercent.toFloat(),
            range = Limits.opacity.toFloatRange(),
            step = 1f,
            unit = "%",
            onValueChange = { v -> update { it.copy(bgOpacityPercent = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "گردی گوشه‌ها",
            value = s.cornerRadiusDp.toFloat(),
            range = Limits.cornerRadius.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(cornerRadiusDp = v.toInt()) } },
        )
    }

    GroupHeader(title = "اندازه", icon = AppIcons.Size)
    SettingsGroup {
        SwitchSetting(
            title = "ارتفاع خودکار (باریک)",
            checked = s.autoHeight,
            onCheckedChange = { v -> update { it.copy(autoHeight = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "عرض کارت",
            value = s.widthPercent.toFloat(),
            range = Limits.sizePercent.toFloatRange(),
            step = 1f,
            unit = "%",
            onValueChange = { v -> update { it.copy(widthPercent = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "ارتفاع کارت",
            value = s.heightPercent.toFloat(),
            range = Limits.sizePercent.toFloatRange(),
            step = 1f,
            unit = "%",
            enabled = !s.autoHeight,
            onValueChange = { v -> update { it.copy(heightPercent = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حاشیهٔ بیرونی",
            value = s.marginDp.toFloat(),
            range = Limits.margin.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(marginDp = v.toInt()) } },
        )
    }
    Text(
        "اندازهٔ ویجت را لانچر تعیین می‌کند؛ درصدها داخل همان فضا اعمال می‌شوند.",
        style = AppTheme.typography.caption,
        color = AppTheme.colors.textSecondary,
        modifier = Modifier.padding(horizontal = 4.dp),
    )

    GroupHeader(title = "فاصلهٔ داخلی", icon = AppIcons.Layers)
    SettingsGroup {
        SliderSetting(
            title = "بالا",
            value = s.paddingTopDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingTopDp = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "پایین",
            value = s.paddingBottomDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingBottomDp = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "ابتدا",
            value = s.paddingStartDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingStartDp = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "انتها",
            value = s.paddingEndDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingEndDp = v.toInt()) } },
        )
    }

    GroupHeader(title = "تراز متن", icon = AppIcons.Align)
    SettingsGroup {
        SegmentedSetting(
            title = "تراز افقی",
            options = horizontal,
            selected = s.hAlign,
            onSelect = { v -> update { it.copy(hAlign = v) } },
        )
        GroupDivider()
        SegmentedSetting(
            title = "تراز عمودی",
            options = vertical,
            selected = s.vAlign,
            onSelect = { v -> update { it.copy(vAlign = v) } },
        )
    }
}

// ====================================================================== BUTTON

@Composable
fun ButtonTab(s: WidgetStyle, update: Updater) {
    GroupHeader(title = "دکمهٔ شمارنده", icon = AppIcons.Counter)
    SettingsGroup {
        SwitchSetting(
            title = "نمایش دکمه روی ویجت",
            checked = s.counterEnabled,
            onCheckedChange = { v -> update { it.copy(counterEnabled = v) } },
        )
    }

    AnimatedVisibility(
        visible = s.counterEnabled,
        enter = fadeIn(tween(200)) + expandVertically(tween(240)),
        exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            GroupHeader(title = "جایگاه", icon = AppIcons.Layers)
            SettingsGroup {
                SegmentedSetting(
                    title = "کنار متن",
                    options = listOf(
                        SegmentOption(CounterSide.RIGHT, "راست"),
                        SegmentOption(CounterSide.LEFT, "چپ"),
                    ),
                    selected = s.counterSide,
                    onSelect = { v -> update { it.copy(counterSide = v) } },
                )
                GroupDivider()
                SliderSetting(
                    title = "فاصله از متن",
                    value = s.counterGapDp.toFloat(),
                    range = Limits.counterGap.toFloatRange(),
                    step = 1f,
                    unit = " dp",
                    onValueChange = { v -> update { it.copy(counterGapDp = v.toInt()) } },
                )
            }

            GroupHeader(title = "ظاهر دکمه", icon = AppIcons.Plus)
            SettingsGroup {
                SliderSetting(
                    title = "اندازهٔ دکمه (نسبت به متن)",
                    value = s.buttonScale,
                    range = Limits.buttonScale,
                    step = 0.05f,
                    decimals = 2,
                    unit = "×",
                    onValueChange = { v -> update { it.copy(buttonScale = v) } },
                )
                GroupDivider()
                SwitchSetting(
                    title = "گردی مثل کادر ویجت",
                    checked = s.buttonRadiusSameAsCard,
                    onCheckedChange = { v -> update { it.copy(buttonRadiusSameAsCard = v) } },
                )
                SliderSetting(
                    title = "گردی گوشهٔ دکمه",
                    value = s.buttonRadiusDp.toFloat(),
                    range = Limits.buttonRadius.toFloatRange(),
                    step = 1f,
                    unit = " dp",
                    enabled = !s.buttonRadiusSameAsCard,
                    onValueChange = { v -> update { it.copy(buttonRadiusDp = v.toInt()) } },
                )
                GroupDivider()
                SliderSetting(
                    title = "شفافیت دکمه",
                    value = s.buttonOpacityPercent.toFloat(),
                    range = Limits.opacity.toFloatRange(),
                    step = 1f,
                    unit = "%",
                    onValueChange = { v -> update { it.copy(buttonOpacityPercent = v.toInt()) } },
                )
                GroupDivider()
                ColorRow(
                    title = "رنگ دکمه",
                    color = s.buttonColor,
                    presets = ButtonPresets,
                    onColorChange = { c -> update { it.copy(buttonColor = c) } },
                )
                GroupDivider()
                ColorRow(
                    title = "رنگ علامت +",
                    color = s.plusColor,
                    presets = BackgroundPresets,
                    onColorChange = { c -> update { it.copy(plusColor = c) } },
                )
            }

            GroupHeader(title = "عدد", icon = AppIcons.TextStyle)
            SettingsGroup {
                SwitchSetting(
                    title = "نمایش عدد",
                    checked = s.showNumber,
                    onCheckedChange = { v -> update { it.copy(showNumber = v) } },
                )
                AnimatedVisibility(visible = s.showNumber) {
                    Column {
                        GroupDivider()
                        SliderSetting(
                            title = "اندازهٔ عدد (نسبت به متن)",
                            value = s.numberScale,
                            range = Limits.numberScale,
                            step = 0.05f,
                            decimals = 2,
                            unit = "×",
                            onValueChange = { v -> update { it.copy(numberScale = v) } },
                        )
                        GroupDivider()
                        SliderSetting(
                            title = "فاصله از دکمه",
                            value = s.numberGapDp.toFloat(),
                            range = Limits.numberGap.toFloatRange(),
                            step = 1f,
                            unit = " dp",
                            onValueChange = { v -> update { it.copy(numberGapDp = v.toInt()) } },
                        )
                        GroupDivider()
                        ColorRow(
                            title = "رنگ عدد",
                            color = s.numberColor,
                            presets = TextPresets,
                            onColorChange = { c -> update { it.copy(numberColor = c) } },
                        )
                    }
                }
            }
        }
    }
}
