package ir.wexipe.ayahwidget.ui.sections

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.wexipe.ayahwidget.data.CounterSide
import ir.wexipe.ayahwidget.data.DEFAULT_AYAH_TEXT
import ir.wexipe.ayahwidget.data.HAlign
import ir.wexipe.ayahwidget.data.Limits
import ir.wexipe.ayahwidget.data.VAlign
import ir.wexipe.ayahwidget.data.WidgetSettings
import ir.wexipe.ayahwidget.data.formatCount
import ir.wexipe.ayahwidget.ui.components.AppIcons
import ir.wexipe.ayahwidget.ui.components.ColorRow
import ir.wexipe.ayahwidget.ui.components.ConfirmDialog
import ir.wexipe.ayahwidget.ui.components.GroupDivider
import ir.wexipe.ayahwidget.ui.components.GroupHeader
import ir.wexipe.ayahwidget.ui.components.SecondaryButton
import ir.wexipe.ayahwidget.ui.components.SegmentOption
import ir.wexipe.ayahwidget.ui.components.SegmentedSetting
import ir.wexipe.ayahwidget.ui.components.SettingsGroup
import ir.wexipe.ayahwidget.ui.components.SliderSetting
import ir.wexipe.ayahwidget.ui.components.SwitchSetting
import ir.wexipe.ayahwidget.ui.components.TonalButton
import ir.wexipe.ayahwidget.ui.components.VerseTextField
import ir.wexipe.ayahwidget.ui.components.toFloatRange
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius
import ir.wexipe.ayahwidget.widget.AppFont
import ir.wexipe.ayahwidget.widget.FontProvider
import ir.wexipe.ayahwidget.widget.WidgetRenderer

/** Every control edits the draft through this function: update { it.copy(...) }. */
typealias Updater = ((WidgetSettings) -> WidgetSettings) -> Unit

private fun argb(hex: Long): Int = (0xFF000000 or hex).toInt()

private val TextPresets = listOf(
    argb(0x0E1E3C), argb(0x1B3A6B), argb(0x000000), argb(0xFFFFFF),
    argb(0xC9A24B), argb(0x2E7D5B), argb(0x7A1F3D),
)
private val BackgroundPresets = listOf(
    argb(0xFFFFFF), argb(0xF2F5FB), argb(0xFFF8E7), argb(0xE6F2EC),
    argb(0x1B3A6B), argb(0x0E1E3C), argb(0x000000),
)
private val ButtonPresets = listOf(
    argb(0x1B3A6B), argb(0x0E1E3C), argb(0x3563C4), argb(0x2E7D5B),
    argb(0x7A1F3D), argb(0xC9A24B), argb(0x000000),
)

// ---------------------------------------------------------------- verse

@Composable
fun VerseTab(s: WidgetSettings, update: Updater) {
    GroupHeader(
        title = "متن آیه",
        icon = AppIcons.Pen,
        action = {
            TonalButton(
                text = "پیش‌فرض",
                icon = AppIcons.Refresh,
                enabled = s.text != DEFAULT_AYAH_TEXT,
                onClick = { update { it.copy(text = DEFAULT_AYAH_TEXT) } },
            )
        },
    )
    VerseTextField(
        value = s.text,
        onValueChange = { v -> update { it.copy(text = v) } },
        placeholder = "متن آیه را بنویسید",
        errorMessage = if (s.text.isBlank()) "متن آیه نمی‌تواند خالی باشد" else null,
    )
}

// ---------------------------------------------------------------- font

@Composable
fun FontTab(s: WidgetSettings, update: Updater) {
    val context = LocalContext.current
    GroupHeader(title = "فونت آیه", icon = AppIcons.Type)
    SettingsGroup {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AppFont.values().forEach { font ->
                FontOptionCard(
                    font = font,
                    selected = s.font == font,
                    available = remember(font) { FontProvider.isCustomAvailable(context, font) },
                    onClick = { update { it.copy(font = font) } },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    GroupHeader(title = "اندازه هوشمند", icon = AppIcons.TextStyle)
    SettingsGroup {
        SegmentedSetting(
            title = "تعداد خط ترجیحی",
            options = Limits.preferredLines.map { SegmentOption(it, it.toString()) },
            selected = s.preferredLines,
            onSelect = { v -> update { it.copy(preferredLines = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حداکثر اندازه متن",
            value = s.fontSizeSp,
            range = Limits.fontSize,
            step = 0.5f,
            decimals = 1,
            unit = " sp",
            onValueChange = { v -> update { it.copy(fontSizeSp = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حداقل اندازهٔ خوانا",
            value = s.minFontSizeSp,
            range = Limits.minFontSize,
            step = 0.5f,
            decimals = 1,
            unit = " sp",
            onValueChange = { v -> update { it.copy(minFontSizeSp = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "مقیاس افقی حروف",
            value = s.textScaleX,
            range = Limits.textScaleX,
            step = 0.01f,
            decimals = 2,
            unit = "×",
            onValueChange = { v -> update { it.copy(textScaleX = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حداقل مقیاس افقی",
            description = "پایین‌ترین فشردگی خودکار برای جا دادن آیه",
            value = s.minTextScaleX,
            range = Limits.minTextScaleX,
            step = 0.01f,
            decimals = 2,
            unit = "×",
            onValueChange = { v -> update { it.copy(minTextScaleX = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "فاصلهٔ خطوط",
            value = s.lineSpacing,
            range = Limits.lineSpacing,
            step = 0.05f,
            decimals = 2,
            unit = "×",
            onValueChange = { v -> update { it.copy(lineSpacing = v) } },
        )
        GroupDivider()
        SliderSetting(
            title = "فاصلهٔ حروف",
            description = "برای متن عربی صفر بماند",
            value = s.letterSpacingEm,
            range = Limits.letterSpacing,
            step = 0.01f,
            decimals = 2,
            unit = " em",
            onValueChange = { v -> update { it.copy(letterSpacingEm = v) } },
        )
    }
}

@Composable
private fun FontOptionCard(
    font: AppFont,
    selected: Boolean,
    available: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    val context = LocalContext.current
    val shape = RoundedCornerShape(Radius.control)
    val border by animateColorAsState(
        if (selected) colors.accent else colors.border, tween(160), label = "fontBorder"
    )
    val bg by animateColorAsState(
        if (selected) colors.primaryContainer else colors.surfaceTint, tween(160), label = "fontBg"
    )
    val family = remember(font) { FontFamily(FontProvider.typeface(context, font)) }

    Column(
        modifier
            .clip(shape)
            .background(bg)
            .border(if (selected) 2.dp else 1.dp, border, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            "وَمَنْ",
            style = TextStyle(fontFamily = family, fontSize = 22.sp, lineHeight = 38.sp, color = colors.textPrimary),
        )
        Text(font.label, style = type.settingTitle, color = if (selected) colors.primary else colors.textPrimary)
        Text(
            if (available) font.englishName else "فایل یافت نشد",
            style = type.caption,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
    }
}

// ---------------------------------------------------------------- colors / card

@Composable
fun ColorsTab(s: WidgetSettings, update: Updater) {
    GroupHeader(title = "رنگ‌ها", icon = AppIcons.Droplet)
    SettingsGroup {
        ColorRow(
            title = "رنگ متن",
            color = s.textColor,
            presets = TextPresets,
            onColorChange = { c -> update { it.copy(textColor = c) } },
        )
        GroupDivider()
        ColorRow(
            title = "رنگ پس‌زمینه",
            color = s.bgColor,
            presets = BackgroundPresets,
            onColorChange = { c -> update { it.copy(bgColor = c) } },
        )
    }
}

@Composable
fun CardTab(s: WidgetSettings, update: Updater) {
    GroupHeader(title = "ظاهر کارت", icon = AppIcons.Card)
    SettingsGroup {
        SliderSetting(
            title = "شفافیت پس‌زمینه",
            value = s.bgOpacityPercent.toFloat(),
            range = Limits.opacity.toFloatRange(),
            step = 1f,
            unit = "%",
            onValueChange = { v -> update { it.copy(bgOpacityPercent = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "گردی گوشه‌ها",
            value = s.cornerRadiusDp.toFloat(),
            range = Limits.cornerRadius.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(cornerRadiusDp = v.toInt()) } },
        )
    }
}

// ---------------------------------------------------------------- size and spacing

@Composable
fun SizeTab(s: WidgetSettings, update: Updater) {
    GroupHeader(title = "اندازهٔ کارت", icon = AppIcons.Size)
    SettingsGroup {
        SliderSetting(
            title = "عرض کارت",
            value = s.widthPercent.toFloat(),
            range = Limits.sizePercent.toFloatRange(),
            step = 1f,
            unit = "%",
            onValueChange = { v -> update { it.copy(widthPercent = v.toInt()) } },
        )
        GroupDivider()
        SwitchSetting(
            title = "ارتفاع خودکار",
            checked = s.autoHeight,
            onCheckedChange = { v -> update { it.copy(autoHeight = v) } },
        )
        SliderSetting(
            title = "ارتفاع کارت",
            value = s.heightPercent.toFloat(),
            range = Limits.sizePercent.toFloatRange(),
            step = 1f,
            unit = "%",
            enabled = !s.autoHeight,
            onValueChange = { v -> update { it.copy(heightPercent = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "حاشیهٔ بیرونی",
            value = s.marginDp.toFloat(),
            range = Limits.margin.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(marginDp = v.toInt()) } },
        )
    }
    // The one real Android limitation worth stating: the launcher owns the widget size.
    Text(
        "اندازهٔ ویجت را لانچر تعیین می‌کند؛ درصدها داخل همان فضا اعمال می‌شوند.",
        style = AppTheme.typography.caption,
        color = AppTheme.colors.textSecondary,
        modifier = Modifier.padding(horizontal = 4.dp),
    )

    GroupHeader(title = "فاصلهٔ داخلی", icon = AppIcons.Layers)
    SettingsGroup {
        SliderSetting(
            title = "بالا",
            value = s.paddingTopDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingTopDp = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "پایین",
            value = s.paddingBottomDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingBottomDp = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "ابتدا",
            value = s.paddingStartDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingStartDp = v.toInt()) } },
        )
        GroupDivider()
        SliderSetting(
            title = "انتها",
            value = s.paddingEndDp.toFloat(),
            range = Limits.padding.toFloatRange(),
            step = 1f,
            unit = " dp",
            onValueChange = { v -> update { it.copy(paddingEndDp = v.toInt()) } },
        )
    }
}

// ---------------------------------------------------------------- layout

@Composable
fun LayoutTab(s: WidgetSettings, update: Updater) {
    // Listed right-to-left so the on-screen order matches the physical alignment.
    val horizontal = listOf(
        SegmentOption(HAlign.RIGHT, "راست", AppIcons.AlignRight),
        SegmentOption(HAlign.CENTER, "وسط", AppIcons.AlignCenter),
        SegmentOption(HAlign.LEFT, "چپ", AppIcons.AlignLeft),
    )
    val vertical = listOf(
        SegmentOption(VAlign.TOP, "بالا", AppIcons.VTop),
        SegmentOption(VAlign.CENTER, "وسط", AppIcons.VCenter),
        SegmentOption(VAlign.BOTTOM, "پایین", AppIcons.VBottom),
    )
    GroupHeader(title = "تراز متن", icon = AppIcons.Align)
    SettingsGroup {
        SegmentedSetting(
            title = "تراز افقی",
            options = horizontal,
            selected = s.hAlign,
            onSelect = { v -> update { it.copy(hAlign = v) } },
        )
        GroupDivider()
        SegmentedSetting(
            title = "تراز عمودی",
            options = vertical,
            selected = s.vAlign,
            onSelect = { v -> update { it.copy(vAlign = v) } },
        )
    }
}

// ---------------------------------------------------------------- counter

@Composable
fun CounterTab(
    s: WidgetSettings,
    update: Updater,
    count: Int,
    onResetCounter: () -> Unit,
) {
    var confirmReset by remember { mutableStateOf(false) }

    GroupHeader(title = "شمارندهٔ خواندن", icon = AppIcons.Counter)
    SettingsGroup {
        SwitchSetting(
            title = "نمایش شمارنده روی ویجت",
            checked = s.counterEnabled,
            onCheckedChange = { v -> update { it.copy(counterEnabled = v) } },
        )
        GroupDivider()
        CounterStatus(count = count, rtl = WidgetRenderer.isRtl(s.text), onReset = { confirmReset = true })
    }

    AnimatedVisibility(
        visible = s.counterEnabled,
        enter = fadeIn(tween(200)) + expandVertically(tween(240)),
        exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            GroupHeader(title = "جایگاه", icon = AppIcons.Layers)
            SettingsGroup {
                SegmentedSetting(
                    title = "کنار متن",
                    options = listOf(
                        SegmentOption(CounterSide.RIGHT, "راست"),
                        SegmentOption(CounterSide.LEFT, "چپ"),
                    ),
                    selected = s.counterSide,
                    onSelect = { v -> update { it.copy(counterSide = v) } },
                )
                GroupDivider()
                SliderSetting(
                    title = "فاصله از آیه",
                    value = s.counterGapDp.toFloat(),
                    range = Limits.counterGap.toFloatRange(),
                    step = 1f,
                    unit = " dp",
                    onValueChange = { v -> update { it.copy(counterGapDp = v.toInt()) } },
                )
            }

            GroupHeader(title = "دکمهٔ +", icon = AppIcons.Plus)
            SettingsGroup {
                SliderSetting(
                    title = "اندازه",
                    value = s.plusSizeDp.toFloat(),
                    range = Limits.plusSize.toFloatRange(),
                    step = 1f,
                    unit = " dp",
                    onValueChange = { v -> update { it.copy(plusSizeDp = v.toInt()) } },
                )
                GroupDivider()
                SliderSetting(
                    title = "گردی گوشه‌ها",
                    value = s.plusRadiusDp.toFloat(),
                    range = Limits.plusRadius.toFloatRange(),
                    step = 1f,
                    unit = " dp",
                    onValueChange = { v -> update { it.copy(plusRadiusDp = v.toInt()) } },
                )
                GroupDivider()
                ColorRow(
                    title = "رنگ دکمه",
                    color = s.buttonColor,
                    presets = ButtonPresets,
                    onColorChange = { c -> update { it.copy(buttonColor = c) } },
                )
                GroupDivider()
                ColorRow(
                    title = "رنگ علامت +",
                    color = s.plusColor,
                    presets = BackgroundPresets,
                    onColorChange = { c -> update { it.copy(plusColor = c) } },
                )
            }

            GroupHeader(title = "عدد", icon = AppIcons.TextStyle)
            SettingsGroup {
                SwitchSetting(
                    title = "نمایش عدد",
                    checked = s.showNumber,
                    onCheckedChange = { v -> update { it.copy(showNumber = v) } },
                )
                AnimatedVisibility(visible = s.showNumber) {
                    Column {
                        GroupDivider()
                        SliderSetting(
                            title = "اندازه",
                            value = s.numberSizeSp,
                            range = Limits.numberSize,
                            step = 1f,
                            unit = " sp",
                            onValueChange = { v -> update { it.copy(numberSizeSp = v) } },
                        )
                        GroupDivider()
                        SliderSetting(
                            title = "فاصله از دکمه",
                            value = s.numberGapDp.toFloat(),
                            range = Limits.numberGap.toFloatRange(),
                            step = 1f,
                            unit = " dp",
                            onValueChange = { v -> update { it.copy(numberGapDp = v.toInt()) } },
                        )
                        GroupDivider()
                        ColorRow(
                            title = "رنگ عدد",
                            color = s.numberColor,
                            presets = TextPresets,
                            onColorChange = { c -> update { it.copy(numberColor = c) } },
                        )
                    }
                }
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "صفر کردن شمارنده؟",
            message = "تعداد فعلی پاک می‌شود و این کار قابل بازگشت نیست.",
            confirmText = "صفر کن",
            cancelText = "انصراف",
            onConfirm = {
                onResetCounter()
                confirmReset = false
            },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
private fun CounterStatus(count: Int, rtl: Boolean, onReset: () -> Unit) {
    val colors = AppTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("تعداد فعلی", style = AppTheme.typography.description, color = colors.textSecondary)
            Text(
                formatCount(count, rtl),
                style = AppTheme.typography.counterDisplay,
                color = colors.textPrimary,
            )
        }
        Spacer(Modifier.width(12.dp))
        SecondaryButton(
            text = "صفر کردن",
            icon = AppIcons.Refresh,
            enabled = count > 0,
            onClick = onReset,
        )
    }
}

// ---------------------------------------------------------------- more

@Composable
fun MoreTab(
    autoApply: Boolean,
    onAutoApplyChange: (Boolean) -> Unit,
    onResetAll: () -> Unit,
) {
    GroupHeader(title = "بیشتر", icon = AppIcons.Tune)
    SettingsGroup {
        SwitchSetting(
            title = "به‌روزرسانی خودکار ویجت",
            description = "هر تغییر، کمی بعد از آخرین ویرایش اعمال می‌شود",
            checked = autoApply,
            onCheckedChange = onAutoApplyChange,
        )
    }
    SecondaryButton(
        text = "بازنشانی همهٔ تنظیمات",
        icon = AppIcons.Refresh,
        onClick = onResetAll,
        modifier = Modifier.fillMaxWidth(),
    )
}
