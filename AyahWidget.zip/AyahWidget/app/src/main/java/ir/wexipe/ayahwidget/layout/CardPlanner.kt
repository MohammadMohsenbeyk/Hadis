package ir.wexipe.ayahwidget.layout

import ir.wexipe.ayahwidget.data.CounterSide
import ir.wexipe.ayahwidget.data.HAlign
import ir.wexipe.ayahwidget.data.VAlign
import ir.wexipe.ayahwidget.data.WidgetStyle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/*
 * Pure layout logic (no Android classes) so it can be unit-tested on a plain JVM.
 *
 * The card is: [ counter block | text ]. The counter block is a square "+" button with the read
 * count under it. Nothing about the button is an absolute size: it is derived from the real height
 * of the text block, so button, text and card always keep the same proportions, whatever the font
 * size, line count or widget size.
 *
 * For the actual widget size the planner picks the best combination of
 *   font size, horizontal glyph scale, line spacing, padding/gap compression, number of lines,
 *   counter compression and layout (side-by-side or stacked),
 * ordered by a "visual cost", and takes the cheapest combination in which everything fits
 * (no overflow, no clipped glyph). Priorities: readable text > two lines > keep the counter >
 * no overflow > comfortable spacing.
 *
 * "Equal line length": the lines of a multi-line text are made visually equal by (1) choosing the
 * line break that minimises the difference, (2) widening the word gaps of the shorter lines by a
 * limited amount, and (3) at most two kashidas (tatweel) per line when the gaps alone are not enough.
 * The font size is identical on every line and letter spacing is never touched.
 */

data class Box(val l: Float, val t: Float, val r: Float, val b: Float) {
    val w: Float get() = r - l
    val h: Float get() = b - t
    val cx: Float get() = (l + r) / 2f
    val cy: Float get() = (t + b) / 2f
}

enum class TextRole { VERSE, NUMBER, GLYPH }

/** inkTop is <= 0 (above the baseline), inkBottom is >= 0 (below the baseline). */
data class LineMetrics(val width: Float, val inkTop: Float, val inkBottom: Float)

interface TextMeasurer {
    fun measure(text: String, role: TextRole, sizePx: Float, scaleX: Float, letterSpacingEm: Float): LineMetrics
}

data class PlanRequest(
    val style: WidgetStyle,
    val text: String,
    val widthPx: Float,
    val heightPx: Float,
    val dp: Float,          // pixels per dp
    val sp: Float,          // pixels per sp
    val rtl: Boolean,
    val counterText: String,
)

/** One word, drawn on its own so that gaps can be controlled exactly. x is the left edge. */
data class PlacedWord(val text: String, val x: Float, val width: Float)

data class VerseLine(val words: List<PlacedWord>, val baseline: Float, val left: Float, val width: Float)

data class VersePlan(
    val lines: List<VerseLine>,
    val sizePx: Float,
    val scaleX: Float,
    val letterSpacingEm: Float,
)

data class CounterPlan(
    val button: Box,
    val radiusPx: Float,
    val glyphSizePx: Float,
    val numberText: String?,
    val numberSizePx: Float,
    val numberCenterX: Float,
    val numberBaseline: Float,
)

enum class PlanMode { SIDE, STACKED, VERSE_ONLY, NOTHING_FITS }

data class CardPlan(
    val card: Box,
    val verse: VersePlan?,
    val counter: CounterPlan?,
    val mode: PlanMode,
    val lineCount: Int,
    val note: String,
)

object CardPlanner {
    fun plan(req: PlanRequest, measurer: TextMeasurer): CardPlan = Planner(req, measurer).run()
}

private class Variant(val counter: Boolean, val number: Boolean)

private class Combo(
    val stacked: Boolean,
    val extra: Int,
    val padF: Float,
    val cntF: Float,
    val sxIdx: Int,
    val lsF: Float,
    val cost: Float,
)

private class WordMetrics(
    val widths: FloatArray,
    val inkTops: FloatArray,
    val inkBottoms: FloatArray,
    val space: Float,
    val inkTop: Float,
    val inkBottom: Float,
)

private class Geom(
    val padT: Float, val padB: Float, val padL: Float, val padR: Float,
    val innerW: Float, val innerHmax: Float,
    val buttonSize: Float, val numberSize: Float, val numberM: LineMetrics?,
    val blockW: Float, val numberGap: Float, val counterGap: Float,
    val blockH: Float, val rowW: Float, val rowH: Float,
    val verseW: Float, val verseHmax: Float,
)

/** One finished line: its words (kashida already inserted), their widths and the gap between them. */
private class LineLayout(
    val words: List<String>,
    val widths: List<Float>,
    val gap: Float,
    val width: Float,
    val inkTop: Float,
    val inkBottom: Float,
)

private class Fit(
    val cand: Combo, val totalCost: Float, val variant: Variant, val geom: Geom,
    val size: Float, val scaleX: Float,
    val lines: List<LineLayout>,
    val pitch: Float, val blockTop: Float, val blockH: Float,
)

private class Planner(val req: PlanRequest, val m: TextMeasurer) {
    private val s = req.style
    private val dp = req.dp
    private val sp = req.sp

    private val margin = s.marginDp * dp
    private val availW = max(1f, req.widthPx - 2f * margin)
    private val availH = max(1f, req.heightPx - 2f * margin)
    private val cardW = max(1f, availW * s.widthPercent / 100f)
    private val cardHMax = max(1f, if (s.autoHeight) availH else availH * s.heightPercent / 100f)

    private val words: List<String> = req.text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private val maxPx = s.fontSizeSp * sp
    private val sizes: FloatArray = buildSizes()
    private val sxs: FloatArray = buildScales()

    private val wordCache = HashMap<Int, WordMetrics>() // sizeIdx*8+sxIdx
    private val numberCache = HashMap<Float, LineMetrics>()

    fun run(): CardPlan {
        val minPx = min(s.minFontSizeSp * sp, maxPx)
        val full = Variant(counter = true, number = true)
        val noNumber = Variant(counter = true, number = false)
        val none = Variant(counter = false, number = false)

        // Priority order: readable text + counter, then a slightly smaller text + counter,
        // then drop the number, then drop the counter, and only at the very end tiny text.
        val passes = ArrayList<Pair<Variant, Float>>()
        if (!s.counterEnabled) {
            passes.add(none to minPx)
            passes.add(none to minPx * 0.8f)
            passes.add(none to 5f * sp)
        } else {
            if (s.showNumber) passes.add(full to minPx)
            passes.add(noNumber to minPx)
            if (s.showNumber) passes.add(full to minPx * 0.8f)
            passes.add(noNumber to minPx * 0.8f)
            passes.add(none to minPx)
            passes.add(none to 5f * sp)
        }
        for ((variant, floor) in passes) {
            val fit = search(variant, floor)
            if (fit != null) return build(fit)
        }
        return lastResort()
    }

    /** The widget is far too small for the text: keep the card and, if possible, the "+" button. */
    private fun lastResort(): CardPlan {
        val cardH = min(cardHMax, availH)
        val left = margin + (availW - cardW) / 2f
        val top = margin + (availH - cardH) / 2f
        val card = Box(left, top, left + cardW, top + cardH)
        if (!s.counterEnabled) return CardPlan(card, null, null, PlanMode.NOTHING_FITS, 0, "nothing fits")
        val side = min(36f * dp, min(cardW, cardH) * 0.7f)
        if (side < 16f * dp) return CardPlan(card, null, null, PlanMode.NOTHING_FITS, 0, "nothing fits")
        val button = Box(card.cx - side / 2f, card.cy - side / 2f, card.cx + side / 2f, card.cy + side / 2f)
        val counter = CounterPlan(button, buttonRadius(side), side * 0.9f, null, 0f, button.cx, button.b)
        return CardPlan(card, null, counter, PlanMode.NOTHING_FITS, 0, "button only")
    }

    private fun buttonRadius(side: Float): Float {
        val dpValue = if (s.buttonRadiusSameAsCard) s.cornerRadiusDp else s.buttonRadiusDp
        return min(dpValue * dp, side / 2f)
    }

    // ---------- candidate search ----------

    private fun buildSizes(): FloatArray {
        val out = ArrayList<Float>()
        var v = maxPx
        val floor = 5f * sp
        while (v >= floor) {
            out.add(v)
            v -= 0.5f * sp
        }
        if (out.isEmpty()) out.add(maxPx)
        return out.toFloatArray()
    }

    private fun buildScales(): FloatArray {
        val userX = s.textScaleX
        val minX = min(s.minTextScaleX, userX)
        return if (abs(userX - minX) < 0.005f) floatArrayOf(userX)
        else floatArrayOf(userX, (userX + minX) / 2f, minX)
    }

    private fun combosFor(v: Variant): List<Combo> {
        val padFs = floatArrayOf(1f, 0.75f, 0.5f)
        val cntFs = if (v.counter) floatArrayOf(1f, 0.8f) else floatArrayOf(1f)
        val lsFs = floatArrayOf(1f, 0.9f)
        val modes = if (v.counter) booleanArrayOf(false, true) else booleanArrayOf(false)
        val extraCost = floatArrayOf(0f, 0.5f, 1.2f, 2.0f, 2.8f, 3.6f)
        val n = words.size
        val out = ArrayList<Combo>()
        for (stacked in modes) {
            for (extra in extraCost.indices) {
                if (extra > 0 && s.preferredLines + extra - 1 >= n) continue
                for (pf in padFs) for (cf in cntFs) for (xi in sxs.indices) for (lf in lsFs) {
                    val sxCost = if (s.textScaleX > 0f) (s.textScaleX - sxs[xi]) / s.textScaleX * 0.8f else 0f
                    // The side-by-side layout is the design; stacked is only a fallback for small widgets.
                    val cost = (1f - pf) * 0.35f + (1f - cf) * 0.5f + sxCost + (1f - lf) * 0.6f +
                        (if (stacked) 1.0f else 0f) + extraCost[extra]
                    out.add(Combo(stacked, extra, pf, cf, xi, lf, cost))
                }
            }
        }
        out.sortBy { it.cost }
        return out
    }

    /**
     * Largest font first. For each size the cheapest relaxation that fits wins; the search stops as
     * soon as a smaller font cannot possibly beat the best cost found so far.
     */
    private fun search(v: Variant, floorPx: Float): Fit? {
        val combos = combosFor(v)
        var best: Fit? = null
        var bestCost = Float.MAX_VALUE
        val readable = s.minFontSizeSp * sp
        for (si in sizes.indices) {
            val size = sizes[si]
            if (size < floorPx - 0.01f) break
            val shrink = (maxPx - size) / maxPx
            // Below the readable size every sp counts much more than above it.
            val penalty = if (size < readable) 3f * (readable - size) / readable else 0f
            val base = shrink + penalty
            if (base >= bestCost) break
            for (c in combos) {
                val total = base + c.cost
                if (total >= bestCost) break
                val fit = evaluate(c, si, total, v)
                if (fit != null) {
                    best = fit
                    bestCost = total
                    break
                }
            }
        }
        return best
    }

    private fun wordMetrics(sizeIdx: Int, sxIdx: Int): WordMetrics =
        wordCache.getOrPut(sizeIdx * 8 + sxIdx) {
            val n = words.size
            val widths = FloatArray(n)
            val tops = FloatArray(n)
            val bottoms = FloatArray(n)
            var top = 0f
            var bottom = 0f
            for (i in 0 until n) {
                val lm = m.measure(words[i], TextRole.VERSE, sizes[sizeIdx], sxs[sxIdx], s.letterSpacingEm)
                widths[i] = lm.width
                tops[i] = lm.inkTop
                bottoms[i] = lm.inkBottom
                top = min(top, lm.inkTop)
                bottom = max(bottom, lm.inkBottom)
            }
            val space = m.measure(" ", TextRole.VERSE, sizes[sizeIdx], sxs[sxIdx], s.letterSpacingEm).width
            WordMetrics(widths, tops, bottoms, space, top, bottom)
        }

    private fun pitchFor(size: Float, c: Combo): Float {
        val userPitch = size * s.lineSpacing
        return max(userPitch * c.lsF, min(userPitch, size * 1.15f))
    }

    private fun geom(c: Combo, v: Variant, size: Float, estTextH: Float): Geom? {
        val padT = s.paddingTopDp * dp * c.padF
        val padB = s.paddingBottomDp * dp * c.padF
        val padStart = s.paddingStartDp * dp * c.padF
        val padEnd = s.paddingEndDp * dp * c.padF
        val padL = if (req.rtl) padEnd else padStart
        val padR = if (req.rtl) padStart else padEnd
        val innerW = cardW - padL - padR
        val innerH = cardHMax - padT - padB
        if (innerW < 16f * dp || innerH < 8f * dp) return null

        var button = 0f
        var numSize = 0f
        var numM: LineMetrics? = null
        var blockW = 0f
        var numGap = 0f
        var blockH = 0f
        var rowW = 0f
        var rowH = 0f
        val counterGap = s.counterGapDp * dp * c.padF
        if (v.counter) {
            var numH = 0f
            if (v.number) {
                numSize = max(7f * sp, size * s.numberScale * c.cntF)
                numM = numberCache.getOrPut(numSize) {
                    m.measure(req.counterText, TextRole.NUMBER, numSize, 1f, 0f)
                }
                numGap = s.numberGapDp * dp * c.padF
                numH = numM.inkBottom - numM.inkTop
            }
            // The whole counter block (button + gap + number) is as tall as the text block.
            val target = estTextH - (if (numM != null) numGap + numH else 0f)
            button = min(60f * dp, max(22f * dp, target * s.buttonScale * c.cntF))
            val numW = numM?.width ?: 0f
            blockW = max(button, numW)
            blockH = button + (if (numM != null) numGap + numH else 0f)
            rowW = button + (if (numM != null) numGap + numW else 0f)
            rowH = max(button, numH)
        }

        val verseW: Float
        val verseH: Float
        if (!v.counter) {
            verseW = innerW
            verseH = innerH
        } else if (!c.stacked) {
            if (blockH > innerH) return null
            verseW = innerW - blockW - counterGap
            verseH = innerH
        } else {
            if (rowW > innerW) return null
            verseW = innerW
            verseH = innerH - rowH - counterGap
        }
        if (verseW < 24f * dp || verseH < 8f * dp) return null
        return Geom(
            padT, padB, padL, padR, innerW, innerH, button, numSize, numM, blockW, numGap,
            counterGap, blockH, rowW, rowH, verseW, verseH,
        )
    }

    private fun evaluate(c: Combo, sizeIdx: Int, totalCost: Float, v: Variant): Fit? {
        val size = sizes[sizeIdx]
        val sx = sxs[c.sxIdx]

        if (words.isEmpty()) {
            val g = geom(c, v, size, 0f) ?: return null
            return Fit(c, totalCost, v, g, size, sx, emptyList(), 0f, 0f, 0f)
        }

        val wm = wordMetrics(sizeIdx, c.sxIdx)
        val k = min(s.preferredLines + c.extra, words.size)
        val pitch = pitchFor(size, c)
        val estTextH = (k - 1) * pitch + (wm.inkBottom - wm.inkTop)
        val g = geom(c, v, size, estTextH) ?: return null

        // Cheap necessary condition before the exact split: the widest line is at least the average.
        var totalW = 0f
        for (w in wm.widths) totalW += w
        if ((totalW + (words.size - k) * wm.space) / k > g.verseW - EPS) return null
        val starts = balancedSplit(wm.widths, wm.space, k, g.verseW - EPS) ?: return null

        // Natural lines.
        val bounds = IntArray(k + 1)
        for (i in 0 until k) bounds[i] = starts[i]
        bounds[k] = words.size
        val naturalWidth = FloatArray(k)
        for (i in 0 until k) {
            var w = 0f
            for (j in bounds[i] until bounds[i + 1]) w += wm.widths[j]
            naturalWidth[i] = w + (bounds[i + 1] - bounds[i] - 1) * wm.space
        }
        val target = naturalWidth.max()

        val lines = ArrayList<LineLayout>(k)
        var top = Float.MAX_VALUE
        var bottom = -Float.MAX_VALUE
        for (i in 0 until k) {
            val idx = bounds[i] until bounds[i + 1]
            val lineWords = idx.map { words[it] }
            val lineWidths = idx.map { wm.widths[it] }
            val layout = if (s.equalLines && k > 1) {
                equalize(lineWords, lineWidths, wm.space, target, g.verseW - EPS, size, sx)
            } else {
                LineLayout(lineWords, lineWidths, wm.space, naturalWidth[i], 0f, 0f)
            }
            var inkTop = 0f
            var inkBottom = 0f
            for (j in idx) {
                inkTop = min(inkTop, wm.inkTops[j])
                inkBottom = max(inkBottom, wm.inkBottoms[j])
            }
            lines.add(LineLayout(layout.words, layout.widths, layout.gap, layout.width, inkTop, inkBottom))
            top = min(top, i * pitch + inkTop)
            bottom = max(bottom, i * pitch + inkBottom)
        }
        val blockH = bottom - top
        if (blockH > g.verseHmax) return null
        return Fit(c, totalCost, v, g, size, sx, lines, pitch, top, blockH)
    }

    /**
     * Widens a line towards [target] without touching the font size: first by a limited amount in
     * every word gap, and when that is not enough by at most two kashidas in suitable words.
     */
    private fun equalize(
        lineWords: List<String>,
        lineWidths: List<Float>,
        space: Float,
        target: Float,
        maxWidth: Float,
        size: Float,
        sx: Float,
    ): LineLayout {
        val n = lineWords.size
        val gaps = n - 1
        val words2 = lineWords.toMutableList()
        val widths2 = lineWidths.toMutableList()
        var natural = widths2.sum() + gaps * space
        val deficit = min(target, maxWidth) - natural
        if (deficit < 0.5f) return LineLayout(words2, widths2, space, natural, 0f, 0f)

        val cap = space * 0.6f
        var remaining = deficit
        if (gaps == 0 || remaining / gaps > cap) {
            // Kashida in the words nearest the middle of the line, at most two.
            val order = lineWords.indices
                .filter { Kashida.bestPosition(lineWords[it]) >= 0 }
                .sortedBy { abs(it - (n - 1) / 2f) }
            var inserted = 0
            for (wi in order) {
                if (inserted == 2) break
                val pos = Kashida.bestPosition(lineWords[wi])
                val longer = Kashida.insert(lineWords[wi], pos)
                val newW = m.measure(longer, TextRole.VERSE, size, sx, s.letterSpacingEm).width
                val delta = newW - lineWidths[wi]
                if (delta <= 0f) continue
                if (remaining - delta < -delta * 0.4f) continue   // would overshoot
                if (natural + delta > maxWidth) continue
                words2[wi] = longer
                widths2[wi] = newW
                natural += delta
                remaining -= delta
                inserted++
                if (gaps > 0 && remaining / gaps <= cap) break
                if (gaps == 0 && remaining < 0.5f) break
            }
        }
        val extra = if (gaps > 0) min(max(remaining, 0f) / gaps, cap) else 0f
        val gap = space + extra
        val width = widths2.sum() + gaps * gap
        return LineLayout(words2, widths2, gap, width, 0f, 0f)
    }

    /**
     * Splits the words into exactly k lines minimising the widest line (then the spread).
     * Returns the index of the first word of every line, or null if some line would exceed maxW.
     */
    private fun balancedSplit(w: FloatArray, space: Float, k: Int, maxW: Float): IntArray? {
        val n = w.size
        if (k > n || k < 1) return null
        val prefix = FloatArray(n + 1)
        for (i in 0 until n) prefix[i + 1] = prefix[i] + w[i]
        fun seg(a: Int, b: Int): Float = prefix[b] - prefix[a] + (b - a - 1) * space

        val inf = Float.MAX_VALUE
        val best = Array(k + 1) { FloatArray(n + 1) { inf } }
        val sq = Array(k + 1) { FloatArray(n + 1) { inf } }
        val prev = Array(k + 1) { IntArray(n + 1) { -1 } }
        for (i in 1..n) {
            val sw = seg(0, i)
            if (sw <= maxW) {
                best[1][i] = sw
                sq[1][i] = sw * sw
            }
        }
        for (j in 2..k) {
            for (i in j..n) {
                for (mid in (j - 1) until i) {
                    if (best[j - 1][mid] == inf) continue
                    val sw = seg(mid, i)
                    if (sw > maxW) continue
                    val mx = max(best[j - 1][mid], sw)
                    val ss = sq[j - 1][mid] + sw * sw
                    val better = mx < best[j][i] - 0.01f || (abs(mx - best[j][i]) <= 0.01f && ss < sq[j][i])
                    if (better) {
                        best[j][i] = mx
                        sq[j][i] = ss
                        prev[j][i] = mid
                    }
                }
            }
        }
        if (best[k][n] == inf) return null
        val starts = IntArray(k)
        var i = n
        for (j in k downTo 1) {
            val mid = if (j == 1) 0 else prev[j][i]
            starts[j - 1] = mid
            i = mid
        }
        return starts
    }

    // ---------- final geometry ----------

    private fun place(h: Float, boxTop: Float, boxH: Float, align: VAlign): Float = when (align) {
        VAlign.TOP -> boxTop
        VAlign.CENTER -> boxTop + (boxH - h) / 2f
        VAlign.BOTTOM -> boxTop + boxH - h
    }

    private fun lineLeft(width: Float, regionL: Float, regionW: Float): Float = when (s.hAlign) {
        HAlign.LEFT -> regionL
        HAlign.RIGHT -> regionL + regionW - width
        HAlign.CENTER -> regionL + (regionW - width) / 2f
    }

    private fun placeWords(line: LineLayout, left: Float): List<PlacedWord> {
        val out = ArrayList<PlacedWord>(line.words.size)
        if (req.rtl) {
            var xr = left + line.width
            for (i in line.words.indices) {
                val x = xr - line.widths[i]
                out.add(PlacedWord(line.words[i], x, line.widths[i]))
                xr = x - line.gap
            }
        } else {
            var x = left
            for (i in line.words.indices) {
                out.add(PlacedWord(line.words[i], x, line.widths[i]))
                x += line.widths[i] + line.gap
            }
        }
        return out
    }

    private fun build(f: Fit): CardPlan {
        val g = f.geom
        val v = f.variant
        val c = f.cand
        val numM = g.numberM

        val contentH = when {
            !v.counter -> f.blockH
            !c.stacked -> max(f.blockH, g.blockH)
            else -> f.blockH + g.counterGap + g.rowH
        }
        val cardH = max(
            1f,
            if (s.autoHeight) min(cardHMax, contentH + g.padT + g.padB) else cardHMax
        )
        val left = margin + (availW - cardW) / 2f
        val top = margin + (availH - cardH) / 2f
        val card = Box(left, top, left + cardW, top + cardH)

        val innerL = left + g.padL
        val innerR = left + cardW - g.padR
        val innerT = top + g.padT
        val innerH = cardH - g.padT - g.padB

        var counterPlan: CounterPlan? = null
        var verseRegionL = innerL
        var verseRegionW = innerR - innerL
        val verseTop: Float
        val mode: PlanMode

        if (!v.counter) {
            verseTop = place(f.blockH, innerT, innerH, s.vAlign)
            mode = PlanMode.VERSE_ONLY
        } else if (!c.stacked) {
            mode = PlanMode.SIDE
            val blockLeft: Float
            if (s.counterSide == CounterSide.LEFT) {
                blockLeft = innerL
                verseRegionL = innerL + g.blockW + g.counterGap
            } else {
                blockLeft = innerR - g.blockW
                verseRegionL = innerL
            }
            verseRegionW = g.verseW
            val blockTop = place(g.blockH, innerT, innerH, s.vAlign)
            val cx = blockLeft + g.blockW / 2f
            val button = Box(cx - g.buttonSize / 2f, blockTop, cx + g.buttonSize / 2f, blockTop + g.buttonSize)
            counterPlan = counterPlan(button, numM, g, cx, button.b + g.numberGap - (numM?.inkTop ?: 0f))
            verseTop = place(f.blockH, innerT, innerH, s.vAlign)
        } else {
            mode = PlanMode.STACKED
            val total = f.blockH + g.counterGap + g.rowH
            val startTop = place(total, innerT, innerH, s.vAlign)
            verseTop = startTop
            val rowTop = startTop + f.blockH + g.counterGap
            val rowLeft = innerL + (innerR - innerL - g.rowW) / 2f
            val numW = numM?.width ?: 0f
            val buttonLeft = if (numM == null || s.counterSide == CounterSide.LEFT) rowLeft
            else rowLeft + numW + g.numberGap
            val rowCy = rowTop + g.rowH / 2f
            val button = Box(buttonLeft, rowCy - g.buttonSize / 2f, buttonLeft + g.buttonSize, rowCy + g.buttonSize / 2f)
            val numLeft = if (s.counterSide == CounterSide.LEFT) buttonLeft + g.buttonSize + g.numberGap else rowLeft
            val baseline = rowCy - ((numM?.inkTop ?: 0f) + (numM?.inkBottom ?: 0f)) / 2f
            counterPlan = counterPlan(button, numM, g, numLeft + numW / 2f, baseline)
        }

        val baseline0 = verseTop - f.blockTop
        val lines = ArrayList<VerseLine>()
        for (i in f.lines.indices) {
            val ln = f.lines[i]
            val l = lineLeft(ln.width, verseRegionL, verseRegionW)
            lines.add(VerseLine(placeWords(ln, l), baseline0 + i * f.pitch, l, ln.width))
        }
        val verse = if (lines.isEmpty()) null else VersePlan(lines, f.size, f.scaleX, s.letterSpacingEm)
        val note = "size=%.1fsp scaleX=%.2f pad=%.2f cnt=%.2f lines=%d mode=%s btn=%.1fdp cost=%.3f".format(
            f.size / sp, f.scaleX, c.padF, c.cntF, f.lines.size, mode, g.buttonSize / dp, f.totalCost
        )
        return CardPlan(card, verse, counterPlan, mode, f.lines.size, note)
    }

    private fun counterPlan(button: Box, numM: LineMetrics?, g: Geom, numberCx: Float, numberBaseline: Float): CounterPlan =
        CounterPlan(
            button = button,
            radiusPx = buttonRadius(g.buttonSize),
            glyphSizePx = g.buttonSize * 0.9f,
            numberText = if (numM != null) req.counterText else null,
            numberSizePx = g.numberSize,
            numberCenterX = numberCx,
            numberBaseline = numberBaseline,
        )

    private companion object {
        const val EPS = 0.75f
    }
}
