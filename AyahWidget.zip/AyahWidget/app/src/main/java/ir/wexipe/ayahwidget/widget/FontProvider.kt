package ir.wexipe.ayahwidget.widget

import android.content.Context
import android.graphics.Typeface

/**
 * The three Mestika weights bundled in app/src/main/assets/fonts/.
 * If a file is missing or is not a real font, a system font is used instead.
 */
enum class AppFont(
    val key: String,
    val label: String,
    val englishName: String,
    val assetFile: String,
    val fallbackFamily: String,
    val fallbackStyle: Int,
) {
    THIN("thin", "نازک", "Thin", "Mestika-Thin.otf", "sans-serif-thin", Typeface.NORMAL),
    MEDIUM("medium", "متوسط", "Medium", "Mestika-Medium.otf", "sans-serif-medium", Typeface.NORMAL),
    BOLD("bold", "ضخیم", "Bold", "Mestika-Bold.otf", "sans-serif", Typeface.BOLD);

    companion object {
        fun fromKey(key: String?): AppFont = values().firstOrNull { it.key == key } ?: MEDIUM
    }
}

object FontProvider {
    private val cache = HashMap<AppFont, Typeface>()
    private val custom = HashSet<AppFont>()

    @Synchronized
    fun typeface(context: Context, font: AppFont): Typeface {
        cache[font]?.let { return it }
        val loaded = loadFromAssets(context.applicationContext, font)
        val result = if (loaded != null) {
            custom.add(font)
            loaded
        } else {
            Typeface.create(font.fallbackFamily, font.fallbackStyle)
        }
        cache[font] = result
        return result
    }

    /** True when the real font file was found and loaded (false = system fallback in use). */
    @Synchronized
    fun isCustomAvailable(context: Context, font: AppFont): Boolean {
        typeface(context, font)
        return font in custom
    }

    private fun loadFromAssets(context: Context, font: AppFont): Typeface? {
        val path = "fonts/${font.assetFile}"
        return try {
            context.assets.open(path).use { input ->
                val header = ByteArray(4)
                if (input.read(header) != 4 || !looksLikeFont(header)) return null
            }
            Typeface.createFromAsset(context.assets, path)
        } catch (e: Exception) {
            null
        }
    }

    private fun looksLikeFont(h: ByteArray): Boolean {
        val tag = String(h, Charsets.ISO_8859_1)
        return tag == "OTTO" || tag == "true" || tag == "ttcf" ||
            (h[0].toInt() == 0 && h[1].toInt() == 1 && h[2].toInt() == 0 && h[3].toInt() == 0)
    }
}
