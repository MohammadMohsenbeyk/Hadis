package ir.wexipe.ayahwidget.data

import android.content.Context
import android.content.SharedPreferences
import ir.wexipe.ayahwidget.widget.AppFont

/**
 * Persists everything in SharedPreferences: appearance settings and the read counter.
 * Survives app kill, widget removal, app update and reboot.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): WidgetSettings {
        val d = WidgetSettings()
        return WidgetSettings(
            text = prefs.getString(K_TEXT, null) ?: d.text,
            font = AppFont.fromKey(prefs.getString(K_FONT, null)),
            fontSizeSp = prefs.getFloat(K_FONT_SIZE, d.fontSizeSp).coerceIn(Limits.fontSize),
            minFontSizeSp = prefs.getFloat(K_MIN_FONT_SIZE, d.minFontSizeSp).coerceIn(Limits.minFontSize),
            textScaleX = prefs.getFloat(K_SCALE_X, d.textScaleX).coerceIn(Limits.textScaleX),
            minTextScaleX = prefs.getFloat(K_MIN_SCALE_X, d.minTextScaleX).coerceIn(Limits.minTextScaleX),
            lineSpacing = prefs.getFloat(K_LINE_SPACING, d.lineSpacing).coerceIn(Limits.lineSpacing),
            letterSpacingEm = prefs.getFloat(K_LETTER_SPACING, d.letterSpacingEm).coerceIn(Limits.letterSpacing),
            preferredLines = prefs.getInt(K_LINES, d.preferredLines).coerceIn(Limits.preferredLines),
            textColor = prefs.getInt(K_TEXT_COLOR, d.textColor),
            bgColor = prefs.getInt(K_BG_COLOR, d.bgColor),
            bgOpacityPercent = prefs.getInt(K_OPACITY, d.bgOpacityPercent).coerceIn(Limits.opacity),
            cornerRadiusDp = prefs.getInt(K_RADIUS, d.cornerRadiusDp).coerceIn(Limits.cornerRadius),
            widthPercent = prefs.getInt(K_WIDTH, d.widthPercent).coerceIn(Limits.sizePercent),
            heightPercent = prefs.getInt(K_HEIGHT, d.heightPercent).coerceIn(Limits.sizePercent),
            autoHeight = prefs.getBoolean(K_AUTO_HEIGHT, d.autoHeight),
            marginDp = prefs.getInt(K_MARGIN, d.marginDp).coerceIn(Limits.margin),
            paddingTopDp = prefs.getInt(K_PAD_TOP, d.paddingTopDp).coerceIn(Limits.padding),
            paddingBottomDp = prefs.getInt(K_PAD_BOTTOM, d.paddingBottomDp).coerceIn(Limits.padding),
            paddingStartDp = prefs.getInt(K_PAD_START, d.paddingStartDp).coerceIn(Limits.padding),
            paddingEndDp = prefs.getInt(K_PAD_END, d.paddingEndDp).coerceIn(Limits.padding),
            hAlign = enumOrDefault(prefs.getString(K_HALIGN, null), d.hAlign),
            vAlign = enumOrDefault(prefs.getString(K_VALIGN, null), d.vAlign),
            counterEnabled = prefs.getBoolean(K_C_ENABLED, d.counterEnabled),
            counterSide = enumOrDefault(prefs.getString(K_C_SIDE, null), d.counterSide),
            counterGapDp = prefs.getInt(K_C_GAP, d.counterGapDp).coerceIn(Limits.counterGap),
            plusSizeDp = prefs.getInt(K_PLUS_SIZE, d.plusSizeDp).coerceIn(Limits.plusSize),
            plusRadiusDp = prefs.getInt(K_PLUS_RADIUS, d.plusRadiusDp).coerceIn(Limits.plusRadius),
            buttonColor = prefs.getInt(K_BUTTON_COLOR, d.buttonColor),
            plusColor = prefs.getInt(K_PLUS_COLOR, d.plusColor),
            showNumber = prefs.getBoolean(K_SHOW_NUMBER, d.showNumber),
            numberSizeSp = prefs.getFloat(K_NUMBER_SIZE, d.numberSizeSp).coerceIn(Limits.numberSize),
            numberGapDp = prefs.getInt(K_NUMBER_GAP, d.numberGapDp).coerceIn(Limits.numberGap),
            numberColor = prefs.getInt(K_NUMBER_COLOR, d.numberColor),
        )
    }

    fun save(s: WidgetSettings) {
        prefs.edit()
            .putString(K_TEXT, s.text)
            .putString(K_FONT, s.font.key)
            .putFloat(K_FONT_SIZE, s.fontSizeSp)
            .putFloat(K_MIN_FONT_SIZE, s.minFontSizeSp)
            .putFloat(K_SCALE_X, s.textScaleX)
            .putFloat(K_MIN_SCALE_X, s.minTextScaleX)
            .putFloat(K_LINE_SPACING, s.lineSpacing)
            .putFloat(K_LETTER_SPACING, s.letterSpacingEm)
            .putInt(K_LINES, s.preferredLines)
            .putInt(K_TEXT_COLOR, s.textColor)
            .putInt(K_BG_COLOR, s.bgColor)
            .putInt(K_OPACITY, s.bgOpacityPercent)
            .putInt(K_RADIUS, s.cornerRadiusDp)
            .putInt(K_WIDTH, s.widthPercent)
            .putInt(K_HEIGHT, s.heightPercent)
            .putBoolean(K_AUTO_HEIGHT, s.autoHeight)
            .putInt(K_MARGIN, s.marginDp)
            .putInt(K_PAD_TOP, s.paddingTopDp)
            .putInt(K_PAD_BOTTOM, s.paddingBottomDp)
            .putInt(K_PAD_START, s.paddingStartDp)
            .putInt(K_PAD_END, s.paddingEndDp)
            .putString(K_HALIGN, s.hAlign.name)
            .putString(K_VALIGN, s.vAlign.name)
            .putBoolean(K_C_ENABLED, s.counterEnabled)
            .putString(K_C_SIDE, s.counterSide.name)
            .putInt(K_C_GAP, s.counterGapDp)
            .putInt(K_PLUS_SIZE, s.plusSizeDp)
            .putInt(K_PLUS_RADIUS, s.plusRadiusDp)
            .putInt(K_BUTTON_COLOR, s.buttonColor)
            .putInt(K_PLUS_COLOR, s.plusColor)
            .putBoolean(K_SHOW_NUMBER, s.showNumber)
            .putFloat(K_NUMBER_SIZE, s.numberSizeSp)
            .putInt(K_NUMBER_GAP, s.numberGapDp)
            .putInt(K_NUMBER_COLOR, s.numberColor)
            .apply()
    }

    // ---- read counter (independent of the appearance settings) ----

    fun loadCounter(): Int = prefs.getInt(K_COUNTER, 0).coerceIn(0, MAX_COUNTER)

    /** Adds one read and returns the new value. Written synchronously so a rapid second tap sees it. */
    fun incrementCounter(): Int {
        val next = (loadCounter() + 1).coerceAtMost(MAX_COUNTER)
        prefs.edit().putInt(K_COUNTER, next).commit()
        return next
    }

    fun resetCounter() {
        prefs.edit().putInt(K_COUNTER, 0).commit()
    }

    fun loadAutoApply(): Boolean = prefs.getBoolean(K_AUTO_APPLY, false)

    fun saveAutoApply(value: Boolean) {
        prefs.edit().putBoolean(K_AUTO_APPLY, value).apply()
    }

    private inline fun <reified E : Enum<E>> enumOrDefault(name: String?, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    companion object {
        const val MAX_COUNTER = 999_999

        private const val PREFS_NAME = "ayah_widget_prefs"
        private const val K_TEXT = "text"
        private const val K_FONT = "font"
        private const val K_FONT_SIZE = "font_size_sp"
        private const val K_MIN_FONT_SIZE = "min_font_size_sp"
        private const val K_SCALE_X = "text_scale_x"
        private const val K_MIN_SCALE_X = "min_text_scale_x"
        private const val K_LINE_SPACING = "line_spacing"
        private const val K_LETTER_SPACING = "letter_spacing_em"
        private const val K_LINES = "preferred_lines"
        private const val K_TEXT_COLOR = "text_color"
        private const val K_BG_COLOR = "bg_color"
        private const val K_OPACITY = "bg_opacity"
        private const val K_RADIUS = "corner_radius_dp"
        private const val K_WIDTH = "width_percent"
        private const val K_HEIGHT = "height_percent"
        private const val K_AUTO_HEIGHT = "auto_height"
        private const val K_MARGIN = "margin_dp"
        private const val K_PAD_TOP = "pad_top_dp"
        private const val K_PAD_BOTTOM = "pad_bottom_dp"
        private const val K_PAD_START = "pad_start_dp"
        private const val K_PAD_END = "pad_end_dp"
        private const val K_HALIGN = "h_align"
        private const val K_VALIGN = "v_align"
        private const val K_C_ENABLED = "counter_enabled"
        private const val K_C_SIDE = "counter_side"
        private const val K_C_GAP = "counter_gap_dp"
        private const val K_PLUS_SIZE = "plus_size_dp"
        private const val K_PLUS_RADIUS = "plus_radius_dp"
        private const val K_BUTTON_COLOR = "button_color"
        private const val K_PLUS_COLOR = "plus_color"
        private const val K_SHOW_NUMBER = "show_number"
        private const val K_NUMBER_SIZE = "number_size_sp"
        private const val K_NUMBER_GAP = "number_gap_dp"
        private const val K_NUMBER_COLOR = "number_color"
        private const val K_COUNTER = "counter_value"
        private const val K_AUTO_APPLY = "auto_apply"
    }
}
