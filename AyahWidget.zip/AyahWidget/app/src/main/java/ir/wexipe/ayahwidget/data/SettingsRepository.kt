package ir.wexipe.ayahwidget.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Single place for all persistence (SharedPreferences, process-safe enough for a widget):
 *   style     - the active appearance
 *   texts     - the text library, each with its own counter
 *   presets   - saved styles
 * Survives app kill, widget removal, app update and reboot.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ style

    fun loadStyle(): WidgetStyle = StyleCodec.decode(prefs.getString(K_STYLE, null))

    fun saveStyle(style: WidgetStyle) {
        prefs.edit().putString(K_STYLE, StyleCodec.encode(style)).apply()
    }

    // ------------------------------------------------------------------ texts

    fun loadTexts(): List<TextItem> {
        ensureSeeded()
        return readIds(K_TEXT_IDS).mapNotNull { readText(it) }
    }

    fun activeTextId(): String {
        val texts = loadTexts()
        val saved = prefs.getString(K_ACTIVE, null)
        return texts.firstOrNull { it.id == saved }?.id ?: texts.first().id
    }

    fun activeText(): TextItem {
        val texts = loadTexts()
        val saved = prefs.getString(K_ACTIVE, null)
        return texts.firstOrNull { it.id == saved } ?: texts.first()
    }

    fun setActiveText(id: String) {
        if (readText(id) == null) return
        prefs.edit().putString(K_ACTIVE, id).putLong(kUsed(id), System.currentTimeMillis()).apply()
    }

    fun addText(text: String): TextItem {
        ensureSeeded()
        val now = System.currentTimeMillis()
        var id = "user_" + now.toString(36)
        val ids = readIds(K_TEXT_IDS)
        var n = 0
        while (id in ids) id = "user_" + now.toString(36) + (++n)
        val item = TextItem(id, text.trim(), 0, false, now, now)
        writeText(item)
        val e = prefs.edit()
        putIds(e, K_TEXT_IDS, ids + id)
        e.apply()
        return item
    }

    fun updateText(id: String, text: String) {
        if (readText(id) == null) return
        prefs.edit().putString(kText(id), text.trim()).apply()
    }

    /** Only user-created texts can be deleted. Returns true when something was removed. */
    fun deleteText(id: String): Boolean {
        val item = readText(id) ?: return false
        if (item.builtIn) return false
        val e = prefs.edit()
        e.remove(kText(id)).remove(kCounter(id)).remove(kBuiltIn(id)).remove(kCreated(id)).remove(kUsed(id))
        putIds(e, K_TEXT_IDS, readIds(K_TEXT_IDS) - id)
        if (prefs.getString(K_ACTIVE, null) == id) e.putString(K_ACTIVE, BuiltInTexts.AYAH_ID)
        e.apply()
        return true
    }

    fun counterOf(id: String): Int = prefs.getInt(kCounter(id), 0).coerceIn(0, MAX_COUNTER)

    fun resetCounter(id: String) {
        prefs.edit().putInt(kCounter(id), 0).commit()
    }

    /** Adds one read to the ACTIVE text and returns its new value. Written synchronously. */
    fun incrementActiveCounter(): Int {
        val id = activeTextId()
        val next = (counterOf(id) + 1).coerceAtMost(MAX_COUNTER)
        prefs.edit().putInt(kCounter(id), next).putLong(kUsed(id), System.currentTimeMillis()).commit()
        return next
    }

    // ------------------------------------------------------------------ presets

    fun loadPresets(): List<StylePreset> =
        readIds(K_PRESET_IDS).mapNotNull { id ->
            val name = prefs.getString(kPresetName(id), null) ?: return@mapNotNull null
            StylePreset(id, name, StyleCodec.decode(prefs.getString(kPresetStyle(id), null)))
        }

    fun savePreset(name: String, style: WidgetStyle): StylePreset {
        val now = System.currentTimeMillis()
        val ids = readIds(K_PRESET_IDS)
        var id = "preset_" + now.toString(36)
        var n = 0
        while (id in ids) id = "preset_" + now.toString(36) + (++n)
        val preset = StylePreset(id, name.trim().ifEmpty { "Style" }, style)
        val e = prefs.edit()
            .putString(kPresetName(id), preset.name)
            .putString(kPresetStyle(id), StyleCodec.encode(style))
        putIds(e, K_PRESET_IDS, ids + id)
        e.apply()
        return preset
    }

    fun deletePreset(id: String) {
        val e = prefs.edit().remove(kPresetName(id)).remove(kPresetStyle(id))
        putIds(e, K_PRESET_IDS, readIds(K_PRESET_IDS) - id)
        e.apply()
    }

    // ------------------------------------------------------------------ misc

    fun loadAutoApply(): Boolean = prefs.getBoolean(K_AUTO_APPLY, false)

    fun saveAutoApply(value: Boolean) {
        prefs.edit().putBoolean(K_AUTO_APPLY, value).apply()
    }

    /** Real size (dp) the launcher gave the widget, so the in-app preview can use the very same size. */
    fun saveWidgetSize(widthDp: Float, heightDp: Float) {
        prefs.edit().putFloat(K_WIDGET_W, widthDp).putFloat(K_WIDGET_H, heightDp).apply()
    }

    fun loadWidgetSize(): Pair<Float, Float>? {
        val w = prefs.getFloat(K_WIDGET_W, 0f)
        val h = prefs.getFloat(K_WIDGET_H, 0f)
        return if (w > 0f && h > 0f) w to h else null
    }

    // ------------------------------------------------------------------ internals

    /** Makes sure every built-in text exists, and migrates data written by the first app version. */
    private fun ensureSeeded() {
        val ids = readIds(K_TEXT_IDS).toMutableList()
        val e = prefs.edit()
        var changed = false
        val now = System.currentTimeMillis()

        for (b in BuiltInTexts.all) {
            if (b.id in ids) continue
            e.putString(kText(b.id), b.text)
                .putInt(kCounter(b.id), 0)
                .putBoolean(kBuiltIn(b.id), true)
                .putLong(kCreated(b.id), now)
                .putLong(kUsed(b.id), 0L)
            ids.add(b.id)
            changed = true
        }

        if (!prefs.getBoolean(K_MIGRATED, false)) {
            val oldCounter = prefs.getInt(K_OLD_COUNTER, 0)
            if (oldCounter > 0) e.putInt(kCounter(BuiltInTexts.AYAH_ID), oldCounter.coerceIn(0, MAX_COUNTER))
            val oldText = prefs.getString(K_OLD_TEXT, null)?.trim()
            if (!oldText.isNullOrEmpty() && oldText != DEFAULT_AYAH_TEXT) {
                val id = "user_migrated"
                e.putString(kText(id), oldText).putInt(kCounter(id), 0).putBoolean(kBuiltIn(id), false)
                    .putLong(kCreated(id), now).putLong(kUsed(id), now)
                ids.add(id)
                e.putString(K_ACTIVE, id)
            }
            e.putBoolean(K_MIGRATED, true)
            changed = true
        }
        if (changed) {
            putIds(e, K_TEXT_IDS, ids)
            e.commit()
        }
    }

    private fun readText(id: String): TextItem? {
        val text = prefs.getString(kText(id), null) ?: return null
        return TextItem(
            id = id,
            text = text,
            counter = counterOf(id),
            builtIn = prefs.getBoolean(kBuiltIn(id), false),
            createdAt = prefs.getLong(kCreated(id), 0L),
            lastUsedAt = prefs.getLong(kUsed(id), 0L),
        )
    }

    private fun writeText(item: TextItem) {
        prefs.edit()
            .putString(kText(item.id), item.text)
            .putInt(kCounter(item.id), item.counter)
            .putBoolean(kBuiltIn(item.id), item.builtIn)
            .putLong(kCreated(item.id), item.createdAt)
            .putLong(kUsed(item.id), item.lastUsedAt)
            .apply()
    }

    private fun readIds(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split(",").filter { it.isNotEmpty() }

    private fun putIds(editor: SharedPreferences.Editor, key: String, ids: List<String>) {
        editor.putString(key, ids.joinToString(","))
    }

    private fun kText(id: String) = "t_${id}_text"
    private fun kCounter(id: String) = "t_${id}_counter"
    private fun kBuiltIn(id: String) = "t_${id}_builtin"
    private fun kCreated(id: String) = "t_${id}_created"
    private fun kUsed(id: String) = "t_${id}_used"
    private fun kPresetName(id: String) = "p_${id}_name"
    private fun kPresetStyle(id: String) = "p_${id}_style"

    companion object {
        const val MAX_COUNTER = 999_999

        private const val PREFS_NAME = "ayah_widget_prefs"
        private const val K_STYLE = "style_v2"
        private const val K_TEXT_IDS = "text_ids"
        private const val K_ACTIVE = "active_text"
        private const val K_PRESET_IDS = "preset_ids"
        private const val K_AUTO_APPLY = "auto_apply"
        private const val K_WIDGET_W = "widget_w_dp"
        private const val K_WIDGET_H = "widget_h_dp"
        private const val K_MIGRATED = "migrated_v2"
        private const val K_OLD_COUNTER = "counter_value"
        private const val K_OLD_TEXT = "text"
    }
}
