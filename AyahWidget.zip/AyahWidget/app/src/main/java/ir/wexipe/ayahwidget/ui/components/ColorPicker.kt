package ir.wexipe.ayahwidget.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius
import java.util.Locale

fun colorToHex(color: Int): String = String.format(Locale.US, "%06X", color and 0xFFFFFF)

private fun opaque(color: Int): Int = color or 0xFF000000.toInt()
private fun sameRgb(a: Int, b: Int) = (a and 0xFFFFFF) == (b and 0xFFFFFF)

/** One color setting as a single tappable row: name, live swatch and HEX code. Opens the picker. */
@Composable
fun ColorRow(
    title: String,
    color: Int,
    presets: List<Int>,
    onColorChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    var open by remember { mutableStateOf(false) }

    Row(
        modifier
            .fillMaxWidth()
            .clickable(role = Role.Button) { open = true }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = AppTheme.typography.settingTitle,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f),
        )
        Row(
            Modifier
                .clip(RoundedCornerShape(percent = 50))
                .background(colors.surfaceTint)
                .border(1.dp, colors.border, RoundedCornerShape(percent = 50))
                .padding(start = 6.dp, end = 12.dp, top = 5.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(Color(opaque(color)))
                    .border(1.dp, colors.borderStrong, CircleShape)
            )
            Spacer(Modifier.width(8.dp))
            Text("#" + colorToHex(color), style = AppTheme.typography.value, color = colors.textPrimary)
        }
    }

    if (open) {
        ColorPickerDialog(
            title = title,
            initial = color,
            presets = presets,
            onDismiss = { open = false },
            onConfirm = {
                onColorChange(it)
                open = false
            },
        )
    }
}

@Composable
private fun Swatch(color: Color, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = AppTheme.colors
    val ring by animateColorAsState(
        if (selected) colors.accent else Color.Transparent, tween(160), label = "ring"
    )
    Box(
        modifier
            .aspectRatio(1f)
            .clip(CircleShape)
            .border(2.dp, ring, CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(3.dp)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(color)
                .border(1.dp, colors.border, CircleShape)
        )
    }
}

/** Full picker: saturation/brightness pad, hue bar, presets and an editable HEX field. */
@Composable
fun ColorPickerDialog(
    title: String,
    initial: Int,
    presets: List<Int>,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    val start = remember(initial) {
        FloatArray(3).also { android.graphics.Color.colorToHSV(opaque(initial), it) }
    }
    var hue by remember { mutableFloatStateOf(start[0]) }
    var sat by remember { mutableFloatStateOf(start[1]) }
    var bri by remember { mutableFloatStateOf(start[2]) }
    var hexText by remember { mutableStateOf(colorToHex(initial)) }

    fun currentColor(): Int =
        android.graphics.Color.HSVToColor(floatArrayOf(hue.coerceIn(0f, 359.9f), sat, bri))

    fun syncHex() {
        hexText = colorToHex(currentColor())
    }

    fun applyColor(argb: Int) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(opaque(argb), hsv)
        hue = hsv[0]
        sat = hsv[1]
        bri = hsv[2]
        hexText = colorToHex(argb)
    }

    val hexValid = hexText.length == 6
    val hexShape = RoundedCornerShape(Radius.control)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(Radius.panel))
                .background(colors.surface)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = type.sectionTitle, color = colors.textPrimary, modifier = Modifier.weight(1f))
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onDismiss),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(AppIcons.Close, contentDescription = "بستن", tint = colors.textSecondary, modifier = Modifier.size(20.dp))
                }
            }

            // Saturation (x) and brightness (y) pad.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(Radius.control))
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown()
                            sat = (down.position.x / size.width).coerceIn(0f, 1f)
                            bri = 1f - (down.position.y / size.height).coerceIn(0f, 1f)
                            syncHex()
                            drag(down.id) { change ->
                                sat = (change.position.x / size.width).coerceIn(0f, 1f)
                                bri = 1f - (change.position.y / size.height).coerceIn(0f, 1f)
                                syncHex()
                                change.consume()
                            }
                        }
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(Brush.horizontalGradient(listOf(Color.White, Color.hsv(hue.coerceIn(0f, 360f), 1f, 1f))))
                    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
                    val c = Offset(sat * size.width, (1f - bri) * size.height)
                    drawCircle(Color.Black.copy(alpha = 0.25f), 12.5.dp.toPx(), c, style = Stroke(1.dp.toPx()))
                    drawCircle(Color.White, 11.dp.toPx(), c, style = Stroke(3.dp.toPx()))
                }
            }

            // Hue bar.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .clip(RoundedCornerShape(percent = 50))
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown()
                            hue = (down.position.x / size.width).coerceIn(0f, 1f) * 360f
                            syncHex()
                            drag(down.id) { change ->
                                hue = (change.position.x / size.width).coerceIn(0f, 1f) * 360f
                                syncHex()
                                change.consume()
                            }
                        }
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(Brush.horizontalGradient((0..6).map { Color.hsv(it * 60f, 1f, 1f) }))
                    val cx = (hue / 360f).coerceIn(0f, 1f) * size.width
                    val c = Offset(cx.coerceIn(14.dp.toPx(), size.width - 14.dp.toPx()), size.height / 2f)
                    drawCircle(Color.Black.copy(alpha = 0.25f), 12.5.dp.toPx(), c, style = Stroke(1.dp.toPx()))
                    drawCircle(Color.White, 11.dp.toPx(), c, style = Stroke(3.dp.toPx()))
                }
            }

            // Presets.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { preset ->
                    Swatch(
                        color = Color(opaque(preset)),
                        selected = hexValid && sameRgb(preset, currentColor()),
                        onClick = { applyColor(preset) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            // Old / new swatches and the HEX input (always left-to-right).
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(46.dp)
                            .clip(hexShape)
                            .background(Color(opaque(initial)))
                            .border(1.dp, colors.border, hexShape)
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .size(46.dp)
                            .clip(hexShape)
                            .background(Color(currentColor()))
                            .border(1.dp, colors.border, hexShape)
                    )
                    Spacer(Modifier.width(14.dp))
                    Row(
                        Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(hexShape)
                            .background(if (hexValid) colors.surfaceTint else colors.dangerContainer)
                            .border(1.dp, if (hexValid) colors.border else colors.danger, hexShape)
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("#", style = type.value, color = colors.textSecondary)
                        Spacer(Modifier.width(4.dp))
                        BasicTextField(
                            value = hexText,
                            onValueChange = { raw ->
                                val cleaned = raw
                                    .filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }
                                    .take(6)
                                    .uppercase(Locale.US)
                                hexText = cleaned
                                if (cleaned.length == 6) {
                                    applyColor(cleaned.toInt(16) or 0xFF000000.toInt())
                                    hexText = cleaned
                                }
                            },
                            singleLine = true,
                            textStyle = type.value.copy(
                                color = colors.textPrimary,
                                textDirection = TextDirection.Ltr,
                            ),
                            cursorBrush = SolidColor(colors.accent),
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Characters,
                                keyboardType = KeyboardType.Ascii,
                            ),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(
                    text = "تأیید رنگ",
                    onClick = { onConfirm(currentColor()) },
                    modifier = Modifier.weight(1.4f),
                    enabled = hexValid,
                    icon = AppIcons.Check,
                )
                SecondaryButton(text = "لغو", onClick = onDismiss, modifier = Modifier.weight(1f))
            }
        }
    }
}
