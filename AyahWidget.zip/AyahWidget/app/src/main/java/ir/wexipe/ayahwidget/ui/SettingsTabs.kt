package ir.wexipe.ayahwidget.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.ui.components.AppIcons
import ir.wexipe.ayahwidget.ui.theme.AppTheme

/** Five categories; one is shown at a time so the screen never becomes a long list. */
enum class SettingsTab(val label: String, val icon: ImageVector) {
    CONTENT("محتوا", AppIcons.Book),
    STYLE("استایل", AppIcons.Droplet),
    TEXT("متن", AppIcons.Type),
    WIDGET("ویجت", AppIcons.Card),
    BUTTON("دکمه", AppIcons.Counter),
}

@Composable
fun SettingsTabBar(
    selected: SettingsTab,
    onSelect: (SettingsTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    val tabs = SettingsTab.values().toList()
    val listState = rememberLazyListState()
    LaunchedEffect(selected) { listState.animateScrollToItem(tabs.indexOf(selected)) }

    LazyRow(
        state = listState,
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(tabs, key = { it.name }) { tab ->
            TabPill(tab = tab, selected = tab == selected, onClick = { onSelect(tab) })
        }
    }
}

@Composable
private fun TabPill(tab: SettingsTab, selected: Boolean, onClick: () -> Unit) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(percent = 50)
    val bg by animateColorAsState(if (selected) colors.primary else colors.surface, tween(200), label = "tabBg")
    val fg by animateColorAsState(if (selected) colors.onPrimary else colors.textSecondary, tween(200), label = "tabFg")
    val border by animateColorAsState(if (selected) colors.primary else colors.border, tween(200), label = "tabBorder")

    Row(
        Modifier
            .height(40.dp)
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(tab.icon, contentDescription = null, tint = fg, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(tab.label, style = AppTheme.typography.tab, color = fg)
    }
}
