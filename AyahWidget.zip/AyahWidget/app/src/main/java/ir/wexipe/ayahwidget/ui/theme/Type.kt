package ir.wexipe.ayahwidget.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.sp

/**
 * Design tokens: type scale. The three Mestika weights have fixed roles:
 *   Bold   -> titles, buttons, numbers (anything that must be found quickly)
 *   Medium -> setting names, tabs, the verse editor
 *   Thin   -> secondary text (descriptions, captions)
 * Colors are applied at the call site.
 */
@Immutable
data class AppTypography(
    val appTitle: TextStyle,
    val sectionTitle: TextStyle,
    val settingTitle: TextStyle,
    val tab: TextStyle,
    val description: TextStyle,
    val caption: TextStyle,
    val value: TextStyle,
    val counterDisplay: TextStyle,
    val button: TextStyle,
    val buttonSmall: TextStyle,
    val verse: TextStyle,
)

fun buildTypography(thin: FontFamily, medium: FontFamily, bold: FontFamily) = AppTypography(
    appTitle = TextStyle(fontFamily = bold, fontSize = 20.sp, lineHeight = 30.sp),
    sectionTitle = TextStyle(fontFamily = bold, fontSize = 16.sp, lineHeight = 24.sp),
    settingTitle = TextStyle(fontFamily = medium, fontSize = 14.sp, lineHeight = 22.sp),
    tab = TextStyle(fontFamily = medium, fontSize = 13.sp, lineHeight = 20.sp),
    description = TextStyle(fontFamily = thin, fontSize = 13.sp, lineHeight = 20.sp),
    caption = TextStyle(fontFamily = thin, fontSize = 12.sp, lineHeight = 18.sp),
    value = TextStyle(fontFamily = bold, fontSize = 13.sp, lineHeight = 18.sp, textDirection = TextDirection.Ltr),
    counterDisplay = TextStyle(fontFamily = bold, fontSize = 32.sp, lineHeight = 40.sp, textDirection = TextDirection.Ltr),
    button = TextStyle(fontFamily = bold, fontSize = 15.sp, lineHeight = 22.sp),
    buttonSmall = TextStyle(fontFamily = bold, fontSize = 13.sp, lineHeight = 20.sp),
    verse = TextStyle(
        fontFamily = medium,
        fontSize = 18.sp,
        lineHeight = 32.sp,
        textDirection = TextDirection.ContentOrRtl,
        textAlign = TextAlign.Start,
    ),
)

val LocalAppTypography = staticCompositionLocalOf {
    buildTypography(FontFamily.Default, FontFamily.Default, FontFamily.Default)
}
