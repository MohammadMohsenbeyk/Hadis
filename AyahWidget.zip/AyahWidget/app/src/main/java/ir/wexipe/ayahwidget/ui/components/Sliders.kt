package ir.wexipe.ayahwidget.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

fun IntRange.toFloatRange(): ClosedFloatingPointRange<Float> = first.toFloat()..last.toFloat()

fun formatValue(value: Float, decimals: Int): String =
    if (decimals <= 0) value.roundToInt().toString()
    else String.format(Locale.US, "%.${decimals}f", value)

internal fun snapToStep(raw: Float, range: ClosedFloatingPointRange<Float>, step: Float): Float {
    val snapped = (raw / step).roundToInt() * step
    val rounded = (snapped * 1000f).roundToInt() / 1000f
    return rounded.coerceIn(range.start, range.endInclusive)
}

/**
 * Slider drawn from scratch: 8dp track, 26dp thumb, 44dp touch height, halo while dragging.
 * It always runs left-to-right (small values on the left), also inside the RTL UI.
 */
@Composable
fun NavySlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    step: Float,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val colors = AppTheme.colors
    val density = LocalDensity.current
    val thumbR = with(density) { 13.dp.toPx() }
    val trackH = with(density) { 8.dp.toPx() }
    val borderW = with(density) { 3.dp.toPx() }

    var pressed by remember { mutableStateOf(false) }
    val halo by animateFloatAsState(if (pressed) 1f else 0f, tween(140), label = "halo")
    val latestOnChange by rememberUpdatedState(onValueChange)
    val latestRange by rememberUpdatedState(valueRange)
    var widthPx by remember { mutableFloatStateOf(1f) }

    fun valueAt(x: Float): Float {
        val usable = max(1f, widthPx - 2f * thumbR)
        val f = ((x - thumbR) / usable).coerceIn(0f, 1f)
        val r = latestRange
        return snapToStep(r.start + f * (r.endInclusive - r.start), r, step)
    }

    var gestures: Modifier = Modifier
    if (enabled) {
        gestures = Modifier
            .pointerInput(step) {
                detectTapGestures(onTap = { latestOnChange(valueAt(it.x)) })
            }
            .pointerInput(step) {
                detectHorizontalDragGestures(
                    onDragStart = {
                        pressed = true
                        latestOnChange(valueAt(it.x))
                    },
                    onDragEnd = { pressed = false },
                    onDragCancel = { pressed = false },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        latestOnChange(valueAt(change.position.x))
                    },
                )
            }
    }

    Box(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .then(gestures)
            .semantics {
                progressBarRangeInfo = ProgressBarRangeInfo(value, valueRange)
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val startX = thumbR
            val endX = size.width - thumbR
            val span = valueRange.endInclusive - valueRange.start
            val frac = if (span <= 0f) 0f else ((value - valueRange.start) / span).coerceIn(0f, 1f)
            val tx = startX + (endX - startX) * frac

            drawLine(colors.track, Offset(startX, cy), Offset(endX, cy), trackH, StrokeCap.Round)
            drawLine(colors.accent, Offset(startX, cy), Offset(tx, cy), trackH, StrokeCap.Round)

            if (halo > 0f) {
                drawCircle(
                    colors.accent.copy(alpha = 0.16f * halo),
                    radius = thumbR * (1f + 0.9f * halo),
                    center = Offset(tx, cy),
                )
            }
            drawCircle(colors.surface, radius = thumbR, center = Offset(tx, cy))
            drawCircle(
                colors.accent,
                radius = thumbR - borderW / 2f,
                center = Offset(tx, cy),
                style = Stroke(width = borderW),
            )
        }
    }
}

@Composable
private fun StepButton(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    val colors = AppTheme.colors
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(colors.surfaceTint)
                .border(1.dp, colors.border, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (enabled) colors.primary else colors.textDisabled,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/**
 * Name, exact current value, and a slider with -/+ buttons for precise steps.
 * Padding is built in so the setting sits correctly inside a SettingsGroup.
 */
@Composable
fun SliderSetting(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    description: String? = null,
    unit: String = "",
    decimals: Int = 0,
    enabled: Boolean = true,
) {
    Column(
        modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.45f)
            .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        SettingHeader(
            title = title,
            description = description,
            value = formatValue(value, decimals) + unit,
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StepButton(AppIcons.Minus, enabled && value > range.start + 1e-4f) {
                    onValueChange(snapToStep(value - step, range, step))
                }
                NavySlider(
                    value = value,
                    onValueChange = onValueChange,
                    valueRange = range,
                    step = step,
                    modifier = Modifier.weight(1f),
                    enabled = enabled,
                )
                StepButton(AppIcons.Plus, enabled && value < range.endInclusive - 1e-4f) {
                    onValueChange(snapToStep(value + step, range, step))
                }
            }
        }
    }
}
