package ir.wexipe.ayahwidget.data

/** Formats the counter. Persian digits are used next to right-to-left text. */
fun formatCount(value: Int, persian: Boolean): String {
    val s = value.toString()
    if (!persian) return s
    val sb = StringBuilder(s.length)
    for (c in s) {
        sb.append(if (c in '0'..'9') ('\u06F0' + (c - '0')) else c)
    }
    return sb.toString()
}
