package ir.wexipe.ayahwidget.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import ir.wexipe.ayahwidget.data.WidgetSettings
import ir.wexipe.ayahwidget.data.formatCount
import ir.wexipe.ayahwidget.layout.Box
import ir.wexipe.ayahwidget.layout.CardPlan
import ir.wexipe.ayahwidget.layout.CardPlanner
import ir.wexipe.ayahwidget.layout.PlanRequest
import ir.wexipe.ayahwidget.layout.TextRole
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** The finished card image plus where the "+" button is (in dp) so callers can make it tappable. */
class RenderedCard(val bitmap: Bitmap, val buttonDp: Box?, val note: String)

/**
 * Draws the whole widget (card, verse, "+" button, counter) into one Bitmap. The in-app preview
 * and the real home-screen widget both use this function, so they are always identical.
 *
 * Why a bitmap: RemoteViews (the only thing a launcher accepts) cannot apply custom fonts,
 * arbitrary corner radii, horizontal glyph scale, letter spacing or exact alpha.
 */
object WidgetRenderer {

    private const val MAX_PIXELS = 1_600_000L

    fun isRtl(text: String): Boolean {
        val t = text.trim()
        return t.isEmpty() || hasRtlLetters(t)
    }

    fun render(
        context: Context,
        s: WidgetSettings,
        widthDp: Float,
        heightDp: Float,
        counter: Int,
        pressed: Boolean = false,
    ): RenderedCard {
        val res = context.resources
        var scale = res.displayMetrics.density
        val fontScale = res.configuration.fontScale

        var w = max(1, (widthDp * scale).roundToInt())
        var h = max(1, (heightDp * scale).roundToInt())
        if (w.toLong() * h.toLong() > MAX_PIXELS) {
            // Keep the bitmap small enough for the RemoteViews binder limit.
            val k = sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h.toDouble())).toFloat()
            scale *= k
            w = max(1, (w * k).roundToInt())
            h = max(1, (h * k).roundToInt())
        }

        val rtl = isRtl(s.text)
        val measurer = AndroidTextMeasurer(context, s)
        val request = PlanRequest(
            settings = s,
            widthPx = w.toFloat(),
            heightPx = h.toFloat(),
            dp = scale,
            sp = scale * fontScale,
            rtl = rtl,
            counterText = formatCount(counter, rtl),
        )
        val plan = CardPlanner.plan(request, measurer)

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bitmap), plan, s, measurer, scale, pressed)

        val button = plan.counter?.button
        val buttonDp = if (button == null) null
        else Box(button.l / scale, button.t / scale, button.r / scale, button.b / scale)
        return RenderedCard(bitmap, buttonDp, plan.note)
    }

    private fun draw(
        canvas: Canvas,
        plan: CardPlan,
        s: WidgetSettings,
        measurer: AndroidTextMeasurer,
        scale: Float,
        pressed: Boolean,
    ) {
        // Card: real corner radius, real alpha.
        val card = plan.card
        val alpha = (s.bgOpacityPercent * 255f / 100f).roundToInt().coerceIn(0, 255)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (s.bgColor and 0x00FFFFFF) or (alpha shl 24)
        }
        val radius = min(s.cornerRadiusDp * scale, min(card.w, card.h) / 2f)
        canvas.drawRoundRect(RectF(card.l, card.t, card.r, card.b), radius, radius, bg)

        // Verse: every line is drawn as one run with the paragraph direction of the text.
        val verse = plan.verse
        if (verse != null) {
            val p = measurer.paint(TextRole.VERSE)
            p.textSize = verse.sizePx
            p.textScaleX = verse.scaleX
            p.letterSpacing = verse.letterSpacingEm
            p.color = s.textColor
            for (line in verse.lines) {
                canvas.drawTextRun(
                    line.text, 0, line.text.length, 0, line.text.length,
                    line.x, line.baseline, hasRtlLetters(line.text), p
                )
            }
        }

        // Counter: square "+" button with the read count under it.
        val counter = plan.counter ?: return
        val b = counter.button
        canvas.save()
        if (pressed) canvas.scale(0.94f, 0.94f, b.cx, b.cy)

        val fill = if (pressed) darken(s.buttonColor, 0.18f) else s.buttonColor
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = fill or 0xFF000000.toInt()
            setShadowLayer(4f * scale, 0f, 1.5f * scale, (0x40 shl 24) or 0x0E1E3C)
        }
        val rect = RectF(b.l, b.t, b.r, b.b)
        canvas.drawRoundRect(rect, counter.radiusPx, counter.radiusPx, shadow)

        val hairline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(1f, scale)
            color = (0x2E shl 24) or 0xFFFFFF
        }
        val inset = hairline.strokeWidth / 2f
        canvas.drawRoundRect(
            RectF(b.l + inset, b.t + inset, b.r - inset, b.b - inset),
            max(0f, counter.radiusPx - inset), max(0f, counter.radiusPx - inset), hairline
        )

        // "+" glyph from the Bold weight, centred on its real ink bounds.
        val gp = measurer.paint(TextRole.GLYPH)
        gp.textSize = counter.glyphSizePx
        gp.textScaleX = 1f
        gp.letterSpacing = 0f
        gp.color = s.plusColor
        val ink = Rect()
        gp.getTextBounds("+", 0, 1, ink)
        canvas.drawText("+", b.cx - (ink.left + ink.right) / 2f, b.cy - (ink.top + ink.bottom) / 2f, gp)
        canvas.restore()

        val number = counter.numberText
        if (number != null) {
            val np = measurer.paint(TextRole.NUMBER)
            np.textSize = counter.numberSizePx
            np.textScaleX = 1f
            np.letterSpacing = 0f
            np.color = s.numberColor
            val width = np.getRunAdvance(number, 0, number.length, 0, number.length, false, number.length)
            canvas.drawText(number, counter.numberCenterX - width / 2f, counter.numberBaseline, np)
        }
    }

    private fun darken(color: Int, amount: Float): Int {
        val k = 1f - amount
        val r = ((color shr 16 and 0xFF) * k).roundToInt()
        val g = ((color shr 8 and 0xFF) * k).roundToInt()
        val b = ((color and 0xFF) * k).roundToInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }
}
