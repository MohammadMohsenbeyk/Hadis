package ir.wexipe.ayahwidget.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import ir.wexipe.ayahwidget.data.WidgetStyle
import ir.wexipe.ayahwidget.data.formatCount
import ir.wexipe.ayahwidget.layout.Box
import ir.wexipe.ayahwidget.layout.CardPlan
import ir.wexipe.ayahwidget.layout.CardPlanner
import ir.wexipe.ayahwidget.layout.PlanRequest
import ir.wexipe.ayahwidget.layout.TextRole
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** The finished card image plus where the "+" button is (in dp) so callers can make it tappable. */
class RenderedCard(val bitmap: Bitmap, val buttonDp: Box?, val note: String)

/**
 * Draws the whole widget (card, text, "+" button, counter) into one Bitmap. The in-app preview and
 * the real home-screen widget both call this one function with the same style, text, counter and
 * size, so they cannot drift apart. The only remaining input that can differ is the size the
 * launcher gives the widget, which is why the app remembers it and previews at exactly that size.
 *
 * Why a bitmap: RemoteViews (the only thing a launcher accepts) cannot apply custom fonts,
 * arbitrary corner radii, horizontal glyph scale, per-word spacing or exact alpha.
 */
object WidgetRenderer {

    private const val MAX_PIXELS = 1_600_000L

    fun isRtl(text: String): Boolean {
        val t = text.trim()
        return t.isEmpty() || hasRtlLetters(t)
    }

    fun render(
        context: Context,
        style: WidgetStyle,
        text: String,
        counter: Int,
        widthDp: Float,
        heightDp: Float,
        pressed: Boolean = false,
    ): RenderedCard {
        val res = context.resources
        var scale = res.displayMetrics.density
        val fontScale = res.configuration.fontScale

        var w = max(1, (widthDp * scale).roundToInt())
        var h = max(1, (heightDp * scale).roundToInt())
        if (w.toLong() * h.toLong() > MAX_PIXELS) {
            // Keep the bitmap small enough for the RemoteViews binder limit.
            val k = sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h.toDouble())).toFloat()
            scale *= k
            w = max(1, (w * k).roundToInt())
            h = max(1, (h * k).roundToInt())
        }

        val rtl = isRtl(text)
        val measurer = AndroidTextMeasurer(context, style)
        val request = PlanRequest(
            style = style,
            text = text,
            widthPx = w.toFloat(),
            heightPx = h.toFloat(),
            dp = scale,
            sp = scale * fontScale,
            rtl = rtl,
            counterText = formatCount(counter, rtl),
        )
        val plan = CardPlanner.plan(request, measurer)

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bitmap), plan, style, measurer, scale, pressed)

        val button = plan.counter?.button
        val buttonDp = if (button == null) null
        else Box(button.l / scale, button.t / scale, button.r / scale, button.b / scale)
        return RenderedCard(bitmap, buttonDp, plan.note)
    }

    private fun withAlpha(color: Int, percent: Int): Int {
        val a = (percent * 255f / 100f).roundToInt().coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (a shl 24)
    }

    private fun draw(
        canvas: Canvas,
        plan: CardPlan,
        s: WidgetStyle,
        measurer: AndroidTextMeasurer,
        scale: Float,
        pressed: Boolean,
    ) {
        // Card: real corner radius, real alpha.
        val card = plan.card
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = withAlpha(s.bgColor, s.bgOpacityPercent)
        }
        val radius = min(s.cornerRadiusDp * scale, min(card.w, card.h) / 2f)
        canvas.drawRoundRect(RectF(card.l, card.t, card.r, card.b), radius, radius, bg)

        // Text: word by word, so the gaps of "equal line length" are exact.
        val verse = plan.verse
        if (verse != null) {
            val p = measurer.paint(TextRole.VERSE)
            p.textSize = verse.sizePx
            p.textScaleX = verse.scaleX
            p.letterSpacing = verse.letterSpacingEm
            p.color = s.textColor
            for (line in verse.lines) {
                for (word in line.words) {
                    canvas.drawTextRun(
                        word.text, 0, word.text.length, 0, word.text.length,
                        word.x, line.baseline, hasRtlLetters(word.text), p
                    )
                }
            }
        }

        // Counter: square "+" button with the read count under it.
        val counter = plan.counter ?: return
        val b = counter.button
        canvas.save()
        if (pressed) canvas.scale(0.94f, 0.94f, b.cx, b.cy)

        val base = if (pressed) darken(s.buttonColor, 0.18f) else s.buttonColor
        val rect = RectF(b.l, b.t, b.r, b.b)
        val surface = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = withAlpha(base, s.buttonOpacityPercent)
            // A drop shadow only looks right under a (nearly) solid button.
            if (s.buttonOpacityPercent >= 85) {
                setShadowLayer(4f * scale, 0f, 1.5f * scale, withAlpha(0x0E1E3C, 25))
            }
        }
        canvas.drawRoundRect(rect, counter.radiusPx, counter.radiusPx, surface)

        val hairline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(1f, scale)
            color = withAlpha(0xFFFFFF, (18 * s.buttonOpacityPercent / 100).coerceAtLeast(6))
        }
        val inset = hairline.strokeWidth / 2f
        val r = max(0f, counter.radiusPx - inset)
        canvas.drawRoundRect(RectF(b.l + inset, b.t + inset, b.r - inset, b.b - inset), r, r, hairline)

        // "+" glyph from the Bold weight, centred on its real ink bounds.
        val gp = measurer.paint(TextRole.GLYPH)
        gp.textSize = counter.glyphSizePx
        gp.textScaleX = 1f
        gp.letterSpacing = 0f
        gp.color = s.plusColor
        val ink = Rect()
        gp.getTextBounds("+", 0, 1, ink)
        canvas.drawText("+", b.cx - (ink.left + ink.right) / 2f, b.cy - (ink.top + ink.bottom) / 2f, gp)
        canvas.restore()

        val number = counter.numberText
        if (number != null) {
            val np = measurer.paint(TextRole.NUMBER)
            np.textSize = counter.numberSizePx
            np.textScaleX = 1f
            np.letterSpacing = 0f
            np.color = s.numberColor
            val width = np.getRunAdvance(number, 0, number.length, 0, number.length, false, number.length)
            canvas.drawText(number, counter.numberCenterX - width / 2f, counter.numberBaseline, np)
        }
    }

    private fun darken(color: Int, amount: Float): Int {
        val k = 1f - amount
        val r = ((color shr 16 and 0xFF) * k).roundToInt()
        val g = ((color shr 8 and 0xFF) * k).roundToInt()
        val b = ((color and 0xFF) * k).roundToInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }
}
