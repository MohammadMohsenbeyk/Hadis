package ir.wexipe.ayahwidget.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/**
 * One consistent icon set: 24x24 grid, 1.75 stroke, round caps and joins, outline only.
 * Icons are tinted at the call site.
 */
object AppIcons {
    val Book by lazy {
        icon(
            "Book",
            "M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z",
            "M5 19.5A1.5 1.5 0 0 0 6.5 21H19v-3"
        )
    }
    val Pen by lazy { icon("Pen", "M4 20h4L19 9l-4-4L4 16z", "M13.5 6.5l4 4") }
    val Type by lazy { icon("Type", "M4 7V5h16v2", "M12 5v14", "M9 19h6") }
    val TextStyle by lazy { icon("TextStyle", "M6 17L12 4l6 13", "M8.5 12h7", "M5 21h14") }
    val Droplet by lazy {
        icon("Droplet", "M12 3.5C12 3.5 18 9 18 14a6 6 0 0 1-12 0c0-5 6-10.5 6-10.5z")
    }
    val Card by lazy {
        icon("Card", "M6 5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z")
    }
    val Layers by lazy { icon("Layers", "M12 3l9 5-9 5-9-5 9-5z", "M3 13l9 5 9-5") }
    val Size by lazy {
        icon("Size", "M4 9V4h5", "M20 9V4h-5", "M4 15v5h5", "M20 15v5h-5")
    }
    val Align by lazy { icon("Align", "M4 6h16", "M9 12h11", "M6 18h14") }
    val Tune by lazy {
        icon(
            "Tune",
            "M4 7h9", "M17 7h3", "M4 17h3", "M11 17h9",
            "M13 7a2 2 0 1 0 4 0a2 2 0 1 0-4 0",
            "M7 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0"
        )
    }
    val Counter by lazy {
        icon("Counter", "M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18z", "M12 8v8", "M8 12h8")
    }
    val Plus by lazy { icon("Plus", "M12 5v14", "M5 12h14") }
    val Minus by lazy { icon("Minus", "M5 12h14") }
    val Refresh by lazy {
        icon(
            "Refresh",
            "M4 12a8 8 0 0 1 14-5.3", "M20 4v4h-4",
            "M20 12a8 8 0 0 1-14 5.3", "M4 20v-4h4"
        )
    }
    val Check by lazy { icon("Check", "M5 12.5l4.5 4.5L19 7.5") }
    val Close by lazy { icon("Close", "M6 6l12 12", "M18 6L6 18") }
    val Alert by lazy {
        icon(
            "Alert",
            "M12 9v4", "M12 17h.01",
            "M10.3 3.9L2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"
        )
    }

    val AlignLeft by lazy { icon("AlignLeft", "M4 6h16", "M4 12h10", "M4 18h14") }
    val AlignCenter by lazy { icon("AlignCenter", "M4 6h16", "M7 12h10", "M5 18h14") }
    val AlignRight by lazy { icon("AlignRight", "M4 6h16", "M10 12h10", "M6 18h14") }

    val VTop by lazy { icon("VTop", "M4 4h16", "M12 20V9", "M8 13l4-4 4 4") }
    val VCenter by lazy {
        icon("VCenter", "M4 12h16", "M12 4v5", "M9 6.5l3 3 3-3", "M12 20v-5", "M9 17.5l3-3 3 3")
    }
    val VBottom by lazy { icon("VBottom", "M4 20h16", "M12 4v11", "M8 11l4 4 4-4") }
}

private fun icon(name: String, vararg paths: String): ImageVector {
    val builder = ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    )
    paths.forEach { d ->
        builder.addPath(
            pathData = PathParser().parsePathString(d).toNodes(),
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 1.75f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
    }
    return builder.build()
}
