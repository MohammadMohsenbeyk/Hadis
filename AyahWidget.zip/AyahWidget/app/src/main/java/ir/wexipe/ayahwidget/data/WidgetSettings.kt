package ir.wexipe.ayahwidget.data

import ir.wexipe.ayahwidget.widget.AppFont

const val DEFAULT_AYAH_TEXT =
    "وَمَنْ يَتَّقِ اللَّهَ يَجْعَلُ لَهُ مَخْرَجًا وَيَرْزُقُهُ مِنْ حَيْثُ لَا يَحْتَسِبُ وَمَنْ يَتَوَكَّلُ عَلَى اللَّهِ فَهُوَ حَسْبُهُ إِنَّ اللَّهَ بَالِغُ أَمْرِهِ"

enum class HAlign { LEFT, CENTER, RIGHT }
enum class VAlign { TOP, CENTER, BOTTOM }

/** Which physical side of the verse the counter block sits on. */
enum class CounterSide { LEFT, RIGHT }

/** Allowed ranges for every numeric setting (used by the UI sliders and by the repository). */
object Limits {
    val fontSize = 12f..40f          // preferred (maximum) verse size, sp
    val minFontSize = 8f..20f        // readability floor for the smart fit, sp
    val textScaleX = 0.85f..1.15f    // horizontal glyph scale chosen by the user
    val minTextScaleX = 0.80f..1.0f  // lowest scale the smart fit may compress to
    val lineSpacing = 1.1f..2.2f     // line pitch as a multiple of the font size
    val letterSpacing = 0f..0.2f     // em
    val preferredLines = 1..4
    val opacity = 0..100
    val cornerRadius = 0..64
    val sizePercent = 30..100
    val margin = 0..32
    val padding = 0..48
    val plusSize = 32..72            // dp
    val plusRadius = 0..36           // dp
    val numberSize = 10f..32f        // sp
    val numberGap = 0..24            // dp, number to button
    val counterGap = 0..40           // dp, counter block to verse
}

data class WidgetSettings(
    // Verse
    val text: String = DEFAULT_AYAH_TEXT,
    val font: AppFont = AppFont.MEDIUM,
    val fontSizeSp: Float = 22f,
    val minFontSizeSp: Float = 12f,
    val textScaleX: Float = 1.0f,
    val minTextScaleX: Float = 0.92f,
    val lineSpacing: Float = 1.45f,
    val letterSpacingEm: Float = 0f,
    val preferredLines: Int = 2,
    val textColor: Int = 0xFF0E1E3C.toInt(),
    // Card
    val bgColor: Int = 0xFFFFFFFF.toInt(),
    val bgOpacityPercent: Int = 94,
    val cornerRadiusDp: Int = 22,
    val widthPercent: Int = 100,
    val heightPercent: Int = 100,
    val autoHeight: Boolean = false,
    val marginDp: Int = 4,
    val paddingTopDp: Int = 10,
    val paddingBottomDp: Int = 10,
    val paddingStartDp: Int = 12,
    val paddingEndDp: Int = 12,
    val hAlign: HAlign = HAlign.CENTER,
    val vAlign: VAlign = VAlign.CENTER,
    // Counter
    val counterEnabled: Boolean = true,
    val counterSide: CounterSide = CounterSide.LEFT,
    val counterGapDp: Int = 12,
    val plusSizeDp: Int = 44,
    val plusRadiusDp: Int = 12,
    val buttonColor: Int = 0xFF1B3A6B.toInt(),
    val plusColor: Int = 0xFFFFFFFF.toInt(),
    val showNumber: Boolean = true,
    val numberSizeSp: Float = 18f,
    val numberGapDp: Int = 6,
    val numberColor: Int = 0xFF0E1E3C.toInt(),
)
