package ir.wexipe.ayahwidget.data

const val DEFAULT_AYAH_TEXT =
    "وَمَنْ يَتَّقِ اللَّهَ يَجْعَلُ لَهُ مَخْرَجًا وَيَرْزُقُهُ مِنْ حَيْثُ لَا يَحْتَسِبُ وَمَنْ يَتَوَكَّلُ عَلَى اللَّهِ فَهُوَ حَسْبُهُ إِنَّ اللَّهَ بَالِغُ أَمْرِهِ"

const val SALAVAT_TEXT = "اللهم صل علی محمد و آل محمد و عجل فرجهم"

/**
 * A text (ayah or dhikr) with its OWN counter. The counter belongs to the text, not to the style,
 * so changing the active text never mixes counts.
 */
data class TextItem(
    val id: String,
    val text: String,
    val counter: Int,
    val builtIn: Boolean,
    val createdAt: Long,
    val lastUsedAt: Long,
) {
    /** Short single-line label for lists. */
    fun title(maxChars: Int = 38): String {
        val t = text.trim().replace(Regex("\\s+"), " ")
        return if (t.length <= maxChars) t else t.take(maxChars).trimEnd() + "…"
    }
}

class BuiltInText(val id: String, val text: String)

/** Suggested texts shipped with the app. Add more here; they appear automatically and cannot be deleted. */
object BuiltInTexts {
    const val AYAH_ID = "builtin_ayah"
    const val SALAVAT_ID = "builtin_salavat"

    val all: List<BuiltInText> = listOf(
        BuiltInText(AYAH_ID, DEFAULT_AYAH_TEXT),
        BuiltInText(SALAVAT_ID, SALAVAT_TEXT),
    )
}

/** A named, saved style. It never contains a text or a counter. */
data class StylePreset(val id: String, val name: String, val style: WidgetStyle)
