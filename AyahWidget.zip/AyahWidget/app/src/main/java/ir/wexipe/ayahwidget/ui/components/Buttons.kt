package ir.wexipe.ayahwidget.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius

enum class ButtonState { Idle, Loading, Success }

/**
 * The main call to action. States: normal, pressed, disabled, loading, success.
 * `enabled` only concerns the idle state; loading and success are always drawn at full strength.
 */
@Composable
fun StatefulPrimaryButton(
    text: String,
    successText: String,
    state: ButtonState,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(Radius.button)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val idle = state == ButtonState.Idle
    val active = enabled || !idle
    val scale by animateFloatAsState(
        if (pressed && enabled && idle) 0.97f else 1f, tween(90), label = "press"
    )
    val bg by animateColorAsState(
        when {
            state == ButtonState.Success -> colors.success
            !active -> colors.track
            pressed -> colors.primaryPressed
            else -> colors.primary
        },
        tween(220), label = "bg"
    )
    val fg = if (active) colors.onPrimary else colors.textSecondary

    Box(
        modifier
            .height(52.dp)
            .scale(scale)
            .shadow(
                elevation = if (active && idle) 6.dp else 0.dp,
                shape = shape,
                ambientColor = colors.primary.copy(alpha = 0.30f),
                spotColor = colors.primary.copy(alpha = 0.40f),
            )
            .clip(shape)
            .background(bg)
            .clickable(
                interactionSource = source,
                indication = null,
                enabled = enabled && idle,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = state,
            transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
            label = "buttonContent",
        ) { st ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                when (st) {
                    ButtonState.Loading -> Spinner(fg)
                    ButtonState.Success -> {
                        Icon(AppIcons.Check, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(successText, style = AppTheme.typography.button, color = fg)
                    }
                    ButtonState.Idle -> {
                        if (icon != null) {
                            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(text, style = AppTheme.typography.button, color = fg)
                    }
                }
            }
        }
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
) {
    StatefulPrimaryButton(
        text = text,
        successText = text,
        state = ButtonState.Idle,
        enabled = enabled,
        onClick = onClick,
        modifier = modifier,
        icon = icon,
    )
}

@Composable
private fun Spinner(color: Color) {
    val transition = rememberInfiniteTransition(label = "spin")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(800, easing = LinearEasing)),
        label = "angle",
    )
    Canvas(Modifier.size(20.dp)) {
        drawArc(
            color = color,
            startAngle = angle,
            sweepAngle = 270f,
            useCenter = false,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
        )
    }
}

/** Quiet outlined button: clearly a button, but far less prominent than the primary action. */
@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(Radius.button)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(90), label = "press")
    val bg by animateColorAsState(
        if (pressed) colors.surfaceTint else colors.surface, tween(120), label = "bg"
    )
    val fg = if (enabled) colors.primary else colors.textDisabled

    Row(
        modifier
            .height(52.dp)
            .scale(scale)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (enabled) colors.borderStrong else colors.border, shape)
            .clickable(
                interactionSource = source,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = AppTheme.typography.button, color = fg)
    }
}

/** For irreversible actions such as resetting the counter. */
@Composable
fun DangerButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(Radius.button)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(90), label = "press")
    Box(
        modifier
            .height(52.dp)
            .scale(scale)
            .clip(shape)
            .background(if (pressed) colors.danger.copy(alpha = 0.85f) else colors.danger)
            .clickable(interactionSource = source, indication = null, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = AppTheme.typography.button, color = Color.White)
    }
}

/** Small tonal button used inside groups (for example "default text"). */
@Composable
fun TonalButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(Radius.control)
    val fg = if (enabled) colors.primary else colors.textDisabled
    val bg = if (enabled) colors.primaryContainer else colors.surfaceTint

    Row(
        modifier
            .height(40.dp)
            .clip(shape)
            .background(bg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = AppTheme.typography.buttonSmall, color = fg)
    }
}
