package ir.wexipe.ayahwidget.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius

/** White surface that holds related settings; rows inside are separated by hairlines. */
@Composable
fun SettingsGroup(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(Radius.card)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = shape,
                ambientColor = colors.shadow.copy(alpha = 0.06f),
                spotColor = colors.shadow.copy(alpha = 0.08f),
            )
            .clip(shape)
            .background(colors.surface)
            .border(1.dp, colors.border, shape),
        content = content,
    )
}

@Composable
fun GroupDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(1.dp)
            .background(AppTheme.colors.border)
    )
}

/** Title of a group with its icon; an optional action sits on the opposite side. */
@Composable
fun GroupHeader(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(icon, size = 32.dp)
        Spacer(Modifier.width(10.dp))
        Text(title, style = AppTheme.typography.sectionTitle, color = AppTheme.colors.textPrimary)
        Spacer(Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
fun IconTile(icon: ImageVector, modifier: Modifier = Modifier, size: Dp = 36.dp) {
    val colors = AppTheme.colors
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.3f))
            .background(colors.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = colors.primary, modifier = Modifier.size(size * 0.56f))
    }
}

/** Setting name (and optional one-line hint) on one side, the current value on the other. */
@Composable
fun SettingHeader(
    title: String,
    modifier: Modifier = Modifier,
    description: String? = null,
    value: String? = null,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = type.settingTitle, color = colors.textPrimary)
            if (description != null) {
                Text(description, style = type.description, color = colors.textSecondary)
            }
        }
        if (value != null) {
            Spacer(Modifier.width(12.dp))
            ValuePill(value)
        }
    }
}

/** Numbers and units always render left-to-right, even inside the RTL UI. */
@Composable
fun ValuePill(text: String, modifier: Modifier = Modifier) {
    val colors = AppTheme.colors
    Box(
        modifier
            .clip(RoundedCornerShape(percent = 50))
            .background(colors.primaryContainer)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = AppTheme.typography.value, color = colors.primary)
    }
}
