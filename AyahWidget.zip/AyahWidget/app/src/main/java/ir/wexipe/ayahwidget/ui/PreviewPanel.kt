package ir.wexipe.ayahwidget.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.data.WidgetSettings
import ir.wexipe.ayahwidget.layout.Box as LayoutBox
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.widget.WidgetRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/** Typical launcher sizes used only for the preview. The real size is decided by the launcher. */
enum class PreviewSize(val label: String, val cols: Int, val rows: Int) {
    X4_1("4×1", 4, 1),
    X4_2("4×2", 4, 2),
    X2_2("2×2", 2, 2);

    fun next(): PreviewSize = values()[(ordinal + 1) % values().size]
}

/**
 * The live preview. It is drawn by the very same renderer as the real widget, on a wallpaper-like
 * backdrop so transparency is visible, and the "+" button is tappable to test the counter.
 */
@Composable
fun PreviewStage(
    settings: WidgetSettings,
    counter: Int,
    previewSize: PreviewSize,
    onIncrement: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(28.dp)

    BoxWithConstraints(
        modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .shadow(
                elevation = 8.dp,
                shape = shape,
                ambientColor = colors.shadow.copy(alpha = 0.14f),
                spotColor = colors.shadow.copy(alpha = 0.20f),
            )
            .clip(shape)
            .drawBehind {
                drawRect(
                    Brush.linearGradient(
                        listOf(Color(0xFF9DB4D8), Color(0xFF4A6AA3), Color(0xFF1F3560)),
                        start = Offset.Zero,
                        end = Offset(this.size.width, this.size.height),
                    )
                )
                val r1 = this.size.width * 0.55f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.32f), Color.Transparent),
                        center = Offset(this.size.width * 0.9f, this.size.height * 0.05f),
                        radius = r1,
                    ),
                    radius = r1,
                    center = Offset(this.size.width * 0.9f, this.size.height * 0.05f),
                )
                val r2 = this.size.width * 0.45f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF7FA0D8).copy(alpha = 0.45f), Color.Transparent),
                        center = Offset(this.size.width * 0.05f, this.size.height * 1.0f),
                        radius = r2,
                    ),
                    radius = r2,
                    center = Offset(this.size.width * 0.05f, this.size.height * 1.0f),
                )
            }
            .border(1.dp, Color.White.copy(alpha = 0.30f), shape)
            .padding(12.dp)
    ) {
        val cell = maxWidth / 4f
        val widthDp = cell * previewSize.cols
        val heightDp = cell * 0.92f * previewSize.rows
        Box(
            Modifier
                .fillMaxWidth()
                .height(heightDp),
            contentAlignment = Alignment.Center,
        ) {
            WidgetPreview(settings, counter, widthDp, heightDp, onIncrement)
        }
    }
}

@Composable
private fun WidgetPreview(
    settings: WidgetSettings,
    counter: Int,
    width: Dp,
    height: Dp,
    onIncrement: () -> Unit,
) {
    val context = LocalContext.current
    var pressed by remember { mutableStateOf(false) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var button by remember { mutableStateOf<LayoutBox?>(null) }
    val latestIncrement by rememberUpdatedState(onIncrement)

    // Same renderer as the widget. The previous frame stays visible while the next one is drawn.
    LaunchedEffect(settings, counter, pressed, width, height) {
        val card = withContext(Dispatchers.Default) {
            WidgetRenderer.render(context, settings, width.value, height.value, counter, pressed)
        }
        image = card.bitmap.asImageBitmap()
        button = card.buttonDp
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.size(width, height)) {
            val current = image
            if (current != null) {
                Image(
                    bitmap = current,
                    contentDescription = "پیش‌نمایش ویجت",
                    modifier = Modifier.size(width, height),
                    contentScale = ContentScale.FillBounds,
                )
            }
            val hit = button
            if (hit != null && settings.counterEnabled) {
                val touch = max(hit.w, 48f)
                val touchH = max(hit.h, 48f)
                Box(
                    Modifier
                        .absoluteOffset(x = (hit.cx - touch / 2f).dp, y = (hit.cy - touchH / 2f).dp)
                        .size(touch.dp, touchH.dp)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    pressed = true
                                    tryAwaitRelease()
                                    pressed = false
                                },
                                onTap = { latestIncrement() },
                            )
                        }
                )
            }
        }
    }
}
