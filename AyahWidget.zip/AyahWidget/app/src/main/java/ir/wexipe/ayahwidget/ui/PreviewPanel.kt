package ir.wexipe.ayahwidget.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.wexipe.ayahwidget.data.WidgetStyle
import ir.wexipe.ayahwidget.layout.Box as LayoutBox
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.widget.WidgetRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/**
 * Sizes the preview can show. ACTUAL is the exact size the launcher gave the real widget (remembered
 * by the widget provider); the others are typical grid sizes for when no widget is placed yet.
 */
enum class PreviewSize(val label: String, val cols: Int, val rows: Int) {
    ACTUAL("اندازهٔ واقعی", 0, 0),
    X4_1("4×1", 4, 1),
    X4_2("4×2", 4, 2),
    X2_2("2×2", 2, 2);

    fun next(hasActual: Boolean): PreviewSize {
        var n = values()[(ordinal + 1) % values().size]
        if (n == ACTUAL && !hasActual) n = values()[(n.ordinal + 1) % values().size]
        return n
    }
}

/** Widget size in dp for a preview choice. Grid sizes derive from the screen width, never from one device. */
@Composable
private fun previewDimensions(size: PreviewSize, actual: Pair<Float, Float>?): Pair<Float, Float> {
    if (size == PreviewSize.ACTUAL && actual != null) return actual
    val screen = LocalConfiguration.current.screenWidthDp.toFloat()
    val cols = if (size == PreviewSize.ACTUAL) 4 else size.cols
    val rows = if (size == PreviewSize.ACTUAL) 1 else size.rows
    return ((screen - 30f) * cols / 4f) to (74f * rows)
}

/**
 * The live preview. The widget is rendered by the very same renderer, at the same dp size as the
 * real widget, and then shown scaled to fit, so every proportion is identical. The "+" button is
 * tappable to test the counter (it counts for real, exactly like the widget).
 */
@Composable
fun PreviewStage(
    style: WidgetStyle,
    text: String,
    counter: Int,
    previewSize: PreviewSize,
    actualSize: Pair<Float, Float>?,
    onIncrement: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    val shape = RoundedCornerShape(28.dp)
    val (widgetW, widgetH) = previewDimensions(previewSize, actualSize)

    BoxWithConstraints(
        modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .shadow(
                elevation = 8.dp,
                shape = shape,
                ambientColor = colors.shadow.copy(alpha = 0.14f),
                spotColor = colors.shadow.copy(alpha = 0.20f),
            )
            .clip(shape)
            .drawBehind {
                drawRect(
                    Brush.linearGradient(
                        listOf(Color(0xFF9DB4D8), Color(0xFF4A6AA3), Color(0xFF1F3560)),
                        start = Offset.Zero,
                        end = Offset(this.size.width, this.size.height),
                    )
                )
                val r1 = this.size.width * 0.55f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.32f), Color.Transparent),
                        center = Offset(this.size.width * 0.9f, this.size.height * 0.05f),
                        radius = r1,
                    ),
                    radius = r1,
                    center = Offset(this.size.width * 0.9f, this.size.height * 0.05f),
                )
                val r2 = this.size.width * 0.45f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF7FA0D8).copy(alpha = 0.45f), Color.Transparent),
                        center = Offset(this.size.width * 0.05f, this.size.height * 1.0f),
                        radius = r2,
                    ),
                    radius = r2,
                    center = Offset(this.size.width * 0.05f, this.size.height * 1.0f),
                )
            }
            .border(1.dp, Color.White.copy(alpha = 0.30f), shape)
            .padding(12.dp)
            .heightIn(min = 96.dp),
        contentAlignment = Alignment.Center,
    ) {
        // The widget is shown at its real size, only scaled down when it is wider than the stage.
        val available = maxWidth.value
        val factor = min(1f, available / widgetW)
        WidgetPreview(
            style = style,
            text = text,
            counter = counter,
            widthDp = widgetW,
            heightDp = widgetH,
            factor = factor,
            onIncrement = onIncrement,
        )
    }
}

@Composable
private fun WidgetPreview(
    style: WidgetStyle,
    text: String,
    counter: Int,
    widthDp: Float,
    heightDp: Float,
    factor: Float,
    onIncrement: () -> Unit,
) {
    val context = LocalContext.current
    var pressed by remember { mutableStateOf(false) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var button by remember { mutableStateOf<LayoutBox?>(null) }
    val latestIncrement by rememberUpdatedState(onIncrement)

    // Same renderer, same inputs as the widget. The previous frame stays visible while the next one is drawn.
    LaunchedEffect(style, text, counter, pressed, widthDp, heightDp) {
        val card = withContext(Dispatchers.Default) {
            WidgetRenderer.render(context, style, text, counter, widthDp, heightDp, pressed)
        }
        image = card.bitmap.asImageBitmap()
        button = card.buttonDp
    }

    val shownW = (widthDp * factor).dp
    val shownH = (heightDp * factor).dp

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.size(shownW, shownH)) {
            val current = image
            if (current != null) {
                Image(
                    bitmap = current,
                    contentDescription = "پیش‌نمایش ویجت",
                    modifier = Modifier.size(shownW, shownH),
                    contentScale = ContentScale.FillBounds,
                )
            }
            val hit = button
            if (hit != null && style.counterEnabled) {
                val touchW = max(hit.w, 48f)
                val touchH = max(hit.h, 48f)
                Box(
                    Modifier
                        .absoluteOffset(x = ((hit.cx - touchW / 2f) * factor).dp, y = ((hit.cy - touchH / 2f) * factor).dp)
                        .size((touchW * factor).dp, (touchH * factor).dp)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    pressed = true
                                    tryAwaitRelease()
                                    pressed = false
                                },
                                onTap = { latestIncrement() },
                            )
                        }
                )
            }
        }
    }
}
