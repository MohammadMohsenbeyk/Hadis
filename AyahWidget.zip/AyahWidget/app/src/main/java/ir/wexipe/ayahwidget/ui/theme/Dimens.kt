package ir.wexipe.ayahwidget.ui.theme

import androidx.compose.ui.unit.dp

/** Design tokens: one corner-radius language for the whole app. */
object Radius {
    val control = 12.dp   // fields, segmented controls, chips
    val button = 16.dp
    val card = 20.dp
    val panel = 24.dp
}
