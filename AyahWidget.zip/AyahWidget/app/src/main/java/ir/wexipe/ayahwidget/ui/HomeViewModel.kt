package ir.wexipe.ayahwidget.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.wexipe.ayahwidget.data.SettingsRepository
import ir.wexipe.ayahwidget.data.StylePreset
import ir.wexipe.ayahwidget.data.TextItem
import ir.wexipe.ayahwidget.data.WidgetStyle
import ir.wexipe.ayahwidget.ui.components.ButtonState
import ir.wexipe.ayahwidget.widget.AyahWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Two kinds of state live here:
 *  - the STYLE is edited as a draft and written to the widget with "Apply" (or automatically);
 *  - CONTENT (texts, active text, counters, presets) is data and is written immediately.
 * The preview and the widget are drawn from the same repository values by the same renderer.
 */
@OptIn(FlowPreview::class)
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository(app)

    // ---- style (draft / saved)
    private val _draft = MutableStateFlow(repo.loadStyle())
    val draft: StateFlow<WidgetStyle> = _draft.asStateFlow()

    private val _saved = MutableStateFlow(_draft.value)
    val saved: StateFlow<WidgetStyle> = _saved.asStateFlow()

    private val _autoApply = MutableStateFlow(repo.loadAutoApply())
    val autoApply: StateFlow<Boolean> = _autoApply.asStateFlow()

    private val _applyState = MutableStateFlow(ButtonState.Idle)
    val applyState: StateFlow<ButtonState> = _applyState.asStateFlow()

    // ---- content
    private val _texts = MutableStateFlow(repo.loadTexts())
    val texts: StateFlow<List<TextItem>> = _texts.asStateFlow()

    private val _activeId = MutableStateFlow(repo.activeTextId())
    val activeId: StateFlow<String> = _activeId.asStateFlow()

    private val _presets = MutableStateFlow(repo.loadPresets())
    val presets: StateFlow<List<StylePreset>> = _presets.asStateFlow()

    private val _widgetSize = MutableStateFlow(repo.loadWidgetSize())
    val widgetSize: StateFlow<Pair<Float, Float>?> = _widgetSize.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        // Optional auto mode: push style changes to the real widget shortly after the last edit.
        viewModelScope.launch {
            _draft.debounce(600).collect { s ->
                if (_autoApply.value && s != _saved.value) commitStyle(s)
            }
        }
    }

    /** Re-reads everything the widget may have changed while the app was closed (taps, resize). */
    fun refresh() {
        _texts.value = repo.loadTexts()
        _activeId.value = repo.activeTextId()
        _widgetSize.value = repo.loadWidgetSize()
    }

    // ------------------------------------------------------------------ style

    fun update(transform: (WidgetStyle) -> WidgetStyle) {
        _draft.update(transform)
    }

    fun setAutoApply(enabled: Boolean) {
        _autoApply.value = enabled
        repo.saveAutoApply(enabled)
        if (enabled && _draft.value != _saved.value) commitStyle(_draft.value)
    }

    fun applyChanges() {
        if (_applyState.value != ButtonState.Idle) return
        val s = _draft.value
        viewModelScope.launch {
            _applyState.value = ButtonState.Loading
            val widgets = withContext(Dispatchers.Default) { commitStyle(s) }
            _applyState.value = ButtonState.Success
            if (widgets == 0) {
                _events.emit("ذخیره شد. ویجت را از بخش Widgets صفحهٔ اصلی اضافه کنید")
            }
            delay(1600)
            _applyState.value = ButtonState.Idle
        }
    }

    fun cancelChanges() {
        _draft.value = _saved.value
    }

    /** Back to the designed default style. Texts and counters are not touched. */
    fun resetStyle() {
        _draft.value = WidgetStyle()
    }

    fun savePreset(name: String) {
        repo.savePreset(name, _draft.value)
        _presets.value = repo.loadPresets()
    }

    fun deletePreset(id: String) {
        repo.deletePreset(id)
        _presets.value = repo.loadPresets()
    }

    /** Loads a preset into the draft (appearance only; counters never come from a preset). */
    fun applyPreset(style: WidgetStyle) {
        _draft.value = style
    }

    // ------------------------------------------------------------------ texts and counters

    fun selectText(id: String) {
        repo.setActiveText(id)
        refresh()
        AyahWidgetProvider.updateAll(getApplication())
    }

    fun createText(text: String) {
        val item = repo.addText(text)
        repo.setActiveText(item.id)
        refresh()
        AyahWidgetProvider.updateAll(getApplication())
    }

    fun updateText(id: String, text: String) {
        repo.updateText(id, text)
        refresh()
        AyahWidgetProvider.updateAll(getApplication())
    }

    fun deleteText(id: String) {
        repo.deleteText(id)
        refresh()
        AyahWidgetProvider.updateAll(getApplication())
    }

    fun resetCounter(id: String) {
        repo.resetCounter(id)
        refresh()
        AyahWidgetProvider.updateAll(getApplication())
    }

    /** Same effect as tapping "+" on the home-screen widget. */
    fun incrementActive() {
        repo.incrementActiveCounter()
        refresh()
        AyahWidgetProvider.updateAll(getApplication())
    }

    /** Saves the style and refreshes every widget on the home screen. Returns the widget count. */
    private fun commitStyle(style: WidgetStyle): Int {
        repo.saveStyle(style)
        _saved.value = style
        return AyahWidgetProvider.updateAll(getApplication())
    }
}
