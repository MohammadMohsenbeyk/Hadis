package ir.wexipe.ayahwidget.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.wexipe.ayahwidget.data.SettingsRepository
import ir.wexipe.ayahwidget.data.WidgetSettings
import ir.wexipe.ayahwidget.ui.components.ButtonState
import ir.wexipe.ayahwidget.widget.AyahWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * draft   = what the user is editing right now (drives the live preview)
 * saved   = what is persisted and drawn on the real widget
 * counter = the read count; independent of the draft, it is always live
 */
@OptIn(FlowPreview::class)
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository(app)

    private val _draft = MutableStateFlow(repo.load())
    val draft: StateFlow<WidgetSettings> = _draft.asStateFlow()

    private val _saved = MutableStateFlow(_draft.value)
    val saved: StateFlow<WidgetSettings> = _saved.asStateFlow()

    private val _autoApply = MutableStateFlow(repo.loadAutoApply())
    val autoApply: StateFlow<Boolean> = _autoApply.asStateFlow()

    private val _counter = MutableStateFlow(repo.loadCounter())
    val counter: StateFlow<Int> = _counter.asStateFlow()

    private val _applyState = MutableStateFlow(ButtonState.Idle)
    val applyState: StateFlow<ButtonState> = _applyState.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        // Optional auto mode: push changes to the real widget shortly after the last edit.
        viewModelScope.launch {
            _draft.debounce(600).collect { s ->
                if (_autoApply.value && s != _saved.value && s.text.isNotBlank()) commit(s)
            }
        }
    }

    fun update(transform: (WidgetSettings) -> WidgetSettings) {
        _draft.update(transform)
    }

    fun setAutoApply(enabled: Boolean) {
        _autoApply.value = enabled
        repo.saveAutoApply(enabled)
        val s = _draft.value
        if (enabled && s != _saved.value && s.text.isNotBlank()) commit(s)
    }

    fun applyChanges() {
        if (_applyState.value != ButtonState.Idle) return
        val s = _draft.value
        if (s.text.isBlank()) return
        viewModelScope.launch {
            _applyState.value = ButtonState.Loading
            val widgets = withContext(Dispatchers.Default) { commit(s) }
            _applyState.value = ButtonState.Success
            if (widgets == 0) {
                _events.emit("ذخیره شد. ویجت را از بخش Widgets صفحهٔ اصلی اضافه کنید")
            }
            delay(1600)
            _applyState.value = ButtonState.Idle
        }
    }

    fun cancelChanges() {
        _draft.value = _saved.value
    }

    fun resetAll() {
        _draft.value = WidgetSettings()
    }

    // ---- counter ----

    fun refreshCounter() {
        _counter.value = repo.loadCounter()
    }

    /** Same effect as tapping "+" on the home-screen widget. */
    fun incrementCounter() {
        _counter.value = repo.incrementCounter()
        AyahWidgetProvider.updateAll(getApplication())
    }

    /** Sets the count to zero and refreshes the widget immediately. */
    fun resetCounter() {
        repo.resetCounter()
        _counter.value = 0
        AyahWidgetProvider.updateAll(getApplication())
    }

    /** Saves and refreshes every widget on the home screen. Returns the widget count. */
    private fun commit(settings: WidgetSettings): Int {
        repo.save(settings)
        _saved.value = settings
        return AyahWidgetProvider.updateAll(getApplication())
    }
}
