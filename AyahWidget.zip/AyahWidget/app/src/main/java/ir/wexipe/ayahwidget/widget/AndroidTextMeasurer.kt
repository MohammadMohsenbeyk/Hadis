package ir.wexipe.ayahwidget.widget

import android.content.Context
import android.graphics.Paint
import android.graphics.Rect
import android.text.TextPaint
import ir.wexipe.ayahwidget.data.WidgetSettings
import ir.wexipe.ayahwidget.layout.LineMetrics
import ir.wexipe.ayahwidget.layout.TextMeasurer
import ir.wexipe.ayahwidget.layout.TextRole

/** True when the text contains right-to-left letters (Arabic, Persian, Hebrew...). */
fun hasRtlLetters(text: String): Boolean = text.any {
    val d = Character.getDirectionality(it)
    d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
}

/**
 * Fonts are assigned by role as part of the design system:
 *   verse  -> the weight chosen by the user (Medium by default)
 *   "+"    -> Bold
 *   number -> Thin
 */
class AndroidTextMeasurer(context: Context, settings: WidgetSettings) : TextMeasurer {

    private val versePaint = newPaint(context, settings.font)
    private val numberPaint = newPaint(context, AppFont.THIN)
    private val glyphPaint = newPaint(context, AppFont.BOLD)
    private val bounds = Rect()

    fun paint(role: TextRole): TextPaint = when (role) {
        TextRole.VERSE -> versePaint
        TextRole.NUMBER -> numberPaint
        TextRole.GLYPH -> glyphPaint
    }

    override fun measure(
        text: String,
        role: TextRole,
        sizePx: Float,
        scaleX: Float,
        letterSpacingEm: Float,
    ): LineMetrics {
        val p = paint(role)
        p.textSize = sizePx
        p.textScaleX = scaleX
        p.letterSpacing = letterSpacingEm
        if (text.isEmpty()) return LineMetrics(0f, 0f, 0f)
        val advance = p.getRunAdvance(text, 0, text.length, 0, text.length, hasRtlLetters(text), text.length)
        p.getTextBounds(text, 0, text.length, bounds)
        // getTextBounds is integer based: add one pixel of safety so nothing is ever clipped.
        return LineMetrics(advance, bounds.top - 1f, bounds.bottom + 1f)
    }

    private fun newPaint(context: Context, font: AppFont): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            typeface = FontProvider.typeface(context, font)
        }
}
