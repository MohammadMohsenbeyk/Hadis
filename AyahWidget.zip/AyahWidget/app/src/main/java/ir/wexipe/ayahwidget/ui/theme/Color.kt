package ir.wexipe.ayahwidget.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Design tokens: color. Navy is the identity; everything else moves toward white. */
@Immutable
data class AppColors(
    val primary: Color,
    val primaryPressed: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val accent: Color,
    val background: Color,
    val surface: Color,
    val surfaceTint: Color,
    val border: Color,
    val borderStrong: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textDisabled: Color,
    val track: Color,
    val shadow: Color,
    val success: Color,
    val danger: Color,
    val dangerContainer: Color,
)

val LightAppColors = AppColors(
    primary = Color(0xFF1B3A6B),
    primaryPressed = Color(0xFF142C52),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE4EBF8),
    accent = Color(0xFF3563C4),
    background = Color(0xFFF5F7FB),
    surface = Color(0xFFFFFFFF),
    surfaceTint = Color(0xFFF2F5FB),
    border = Color(0xFFE2E8F2),
    borderStrong = Color(0xFFCBD5E4),
    textPrimary = Color(0xFF0E1E3C),
    textSecondary = Color(0xFF52627D),
    textDisabled = Color(0xFFA5B1C4),
    track = Color(0xFFDDE4F0),
    shadow = Color(0xFF0E1E3C),
    success = Color(0xFF1F8A5B),
    danger = Color(0xFFC2453D),
    dangerContainer = Color(0xFFFBEDEC),
)

val LocalAppColors = staticCompositionLocalOf { LightAppColors }
