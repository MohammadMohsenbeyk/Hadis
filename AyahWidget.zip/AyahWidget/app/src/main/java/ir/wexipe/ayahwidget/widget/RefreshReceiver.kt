package ir.wexipe.ayahwidget.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-draws the widget after a reboot or an app update. */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AyahWidgetProvider.updateAll(context)
    }
}
