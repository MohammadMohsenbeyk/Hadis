package ir.wexipe.ayahwidget.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.wexipe.ayahwidget.data.formatCount
import ir.wexipe.ayahwidget.ui.theme.AppTheme
import ir.wexipe.ayahwidget.ui.theme.Radius
import ir.wexipe.ayahwidget.widget.WidgetRenderer

/** Confirmation for irreversible actions. The destructive answer is red, the safe one is neutral. */
@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    cancelText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(Radius.panel))
                .background(colors.surface)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(title, style = type.sectionTitle, color = colors.textPrimary)
            Text(message, style = type.settingTitle, color = colors.textSecondary)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                DangerButton(text = confirmText, onClick = onConfirm, modifier = Modifier.weight(1f))
                SecondaryButton(text = cancelText, onClick = onDismiss, modifier = Modifier.weight(1f))
            }
        }
    }
}

/** Asks for the name of a style preset. */
@Composable
fun PresetNameDialog(
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AppTheme.colors
    var name by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(Radius.panel))
                .background(colors.surface)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("ذخیرهٔ استایل", style = AppTheme.typography.sectionTitle, color = colors.textPrimary)
            SimpleTextField(value = name, onValueChange = { name = it.take(32) }, placeholder = "نام استایل")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(
                    text = "ذخیره",
                    onClick = { onSave(name.trim()) },
                    enabled = name.isNotBlank(),
                    modifier = Modifier.weight(1.4f),
                    icon = AppIcons.Check,
                )
                SecondaryButton(text = "لغو", onClick = onDismiss, modifier = Modifier.weight(1f))
            }
        }
    }
}

/**
 * The settings page of one text: edit it, see and reset its counter, delete it (user texts only).
 * Used for creating a new text as well (counter = null, no delete).
 */
@Composable
fun TextEditorDialog(
    title: String,
    initialText: String,
    counter: Int?,
    canDelete: Boolean,
    onSave: (String) -> Unit,
    onResetCounter: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AppTheme.colors
    val type = AppTheme.typography
    var text by remember { mutableStateOf(initialText) }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .heightIn(max = 640.dp)
                .clip(RoundedCornerShape(Radius.panel))
                .background(colors.surface)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(title, style = type.sectionTitle, color = colors.textPrimary)

            VerseTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = "متن را بنویسید",
                errorMessage = if (text.isBlank()) "متن نمی‌تواند خالی باشد" else null,
            )

            if (counter != null) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("تعداد فعلی", style = type.description, color = colors.textSecondary)
                        Text(
                            formatCount(counter, WidgetRenderer.isRtl(text)),
                            style = type.counterDisplay,
                            color = colors.textPrimary,
                        )
                    }
                    SecondaryButton(
                        text = "صفر کردن",
                        icon = AppIcons.Refresh,
                        enabled = counter > 0,
                        onClick = { confirmReset = true },
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(
                    text = "ذخیره",
                    onClick = { onSave(text.trim()) },
                    enabled = text.isNotBlank(),
                    modifier = Modifier.weight(1.4f),
                    icon = AppIcons.Check,
                )
                SecondaryButton(text = "لغو", onClick = onDismiss, modifier = Modifier.weight(1f))
            }

            if (canDelete) {
                DangerButton(text = "حذف این متن", onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth())
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "صفر کردن شمارنده؟",
            message = "شمارندهٔ همین متن پاک می‌شود و قابل بازگشت نیست.",
            confirmText = "صفر کن",
            cancelText = "انصراف",
            onConfirm = {
                onResetCounter()
                confirmReset = false
            },
            onDismiss = { confirmReset = false },
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "حذف متن؟",
            message = "متن و شمارندهٔ آن برای همیشه پاک می‌شود.",
            confirmText = "حذف",
            cancelText = "انصراف",
            onConfirm = {
                confirmDelete = false
                onDelete()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
