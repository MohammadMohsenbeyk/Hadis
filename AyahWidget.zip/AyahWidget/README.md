# ویجت آیه (AyahWidget)

اپ اندروید با ویجت واقعی صفحهٔ اصلی: کارت آیه (پیش‌فرض دو خطی) + دکمهٔ «+» و شمارندهٔ تعداد خواندن.
هدف: Samsung Galaxy A50 / Android 10 (minSdk 26).

## فونت‌ها
سه فایل Mestika داخل `app/src/main/assets/fonts/` هستند (Thin / Medium / Bold).
نقش‌ها: آیه = Medium (قابل تغییر)، علامت + = Bold، عدد شمارنده = Thin.

## بیلد
هر Push به شاخهٔ `main` در GitHub Actions بیلد می‌شود. فایل APK از Actions ← آخرین اجرا ← Artifacts دانلود می‌شود.

## ساختار
- `layout/CardPlanner.kt` منطق چیدمان هوشمند (بدون وابستگی به Android؛ روی JVM تست شده)
- `widget/` رندر کارت (Canvas)، Provider ویجت، فونت‌ها
- `data/` تنظیمات و شمارنده (SharedPreferences)
- `ui/theme/` Design System — `ui/components/` کنترل‌های سفارشی — `ui/sections/` محتوای تب‌ها
