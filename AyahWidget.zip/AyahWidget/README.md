# AyehWidget

Slim two-line ayeh/dhikr widget for the Android home screen with a read counter.
Target: Samsung Galaxy A50 / Android 10 (minSdk 26); layout is dp/sp based, so other densities work too.

- `layout/CardPlanner.kt` - smart layout (pure Kotlin, unit-tested on a JVM): two lines, equal line length, button sized from the text
- `widget/` - one renderer used by BOTH the widget and the in-app preview, widget provider, fonts
- `data/` - style (+ presets), text library with an independent counter per text
- `ui/` - Compose UI, design system in `ui/theme`, controls in `ui/components`, tabs in `ui/sections`

Build: every push to `main` builds an APK in GitHub Actions (Artifacts).
